<?php return array (
  'app' => 
  array (
    'name' => 'omar',
    'env' => 'local',
    'debug' => true,
    'url' => 'http://localhost',
    'asset_url' => NULL,
    'timezone' => 'UTC',
    'locale' => 'ar',
    'fallback_locale' => 'ar',
    'faker_locale' => 'en_US',
    'key' => 'base64:1xQBBGzFTwD5rHsBwFZ59x+mlZf83oY9sgFiaVttjIw=',
    'cipher' => 'AES-256-CBC',
    'providers' => 
    array (
      0 => 'Illuminate\\Auth\\AuthServiceProvider',
      1 => 'Illuminate\\Broadcasting\\BroadcastServiceProvider',
      2 => 'Illuminate\\Bus\\BusServiceProvider',
      3 => 'Illuminate\\Cache\\CacheServiceProvider',
      4 => 'Illuminate\\Foundation\\Providers\\ConsoleSupportServiceProvider',
      5 => 'Illuminate\\Cookie\\CookieServiceProvider',
      6 => 'Illuminate\\Database\\DatabaseServiceProvider',
      7 => 'Illuminate\\Encryption\\EncryptionServiceProvider',
      8 => 'Illuminate\\Filesystem\\FilesystemServiceProvider',
      9 => 'Illuminate\\Foundation\\Providers\\FoundationServiceProvider',
      10 => 'Illuminate\\Hashing\\HashServiceProvider',
      11 => 'Illuminate\\Mail\\MailServiceProvider',
      12 => 'Illuminate\\Notifications\\NotificationServiceProvider',
      13 => 'Illuminate\\Pagination\\PaginationServiceProvider',
      14 => 'Illuminate\\Pipeline\\PipelineServiceProvider',
      15 => 'Illuminate\\Queue\\QueueServiceProvider',
      16 => 'Illuminate\\Redis\\RedisServiceProvider',
      17 => 'Illuminate\\Auth\\Passwords\\PasswordResetServiceProvider',
      18 => 'Illuminate\\Session\\SessionServiceProvider',
      19 => 'Illuminate\\Translation\\TranslationServiceProvider',
      20 => 'Illuminate\\Validation\\ValidationServiceProvider',
      21 => 'Illuminate\\View\\ViewServiceProvider',
      22 => 'Vimeo\\Laravel\\VimeoServiceProvider',
      23 => 'Laravel\\Socialite\\SocialiteServiceProvider',
      24 => 'App\\Providers\\MetronicServiceProvider',
      25 => 'App\\Providers\\AppServiceProvider',
      26 => 'App\\Providers\\AuthServiceProvider',
      27 => 'App\\Providers\\EventServiceProvider',
      28 => 'App\\Providers\\RouteServiceProvider',
    ),
    'aliases' => 
    array (
      'App' => 'Illuminate\\Support\\Facades\\App',
      'Arr' => 'Illuminate\\Support\\Arr',
      'Artisan' => 'Illuminate\\Support\\Facades\\Artisan',
      'Auth' => 'Illuminate\\Support\\Facades\\Auth',
      'Blade' => 'Illuminate\\Support\\Facades\\Blade',
      'Broadcast' => 'Illuminate\\Support\\Facades\\Broadcast',
      'Bus' => 'Illuminate\\Support\\Facades\\Bus',
      'Cache' => 'Illuminate\\Support\\Facades\\Cache',
      'Config' => 'Illuminate\\Support\\Facades\\Config',
      'Cookie' => 'Illuminate\\Support\\Facades\\Cookie',
      'Crypt' => 'Illuminate\\Support\\Facades\\Crypt',
      'DB' => 'Illuminate\\Support\\Facades\\DB',
      'Eloquent' => 'Illuminate\\Database\\Eloquent\\Model',
      'Event' => 'Illuminate\\Support\\Facades\\Event',
      'File' => 'Illuminate\\Support\\Facades\\File',
      'Gate' => 'Illuminate\\Support\\Facades\\Gate',
      'Hash' => 'Illuminate\\Support\\Facades\\Hash',
      'Http' => 'Illuminate\\Support\\Facades\\Http',
      'Lang' => 'Illuminate\\Support\\Facades\\Lang',
      'Log' => 'Illuminate\\Support\\Facades\\Log',
      'Mail' => 'Illuminate\\Support\\Facades\\Mail',
      'Notification' => 'Illuminate\\Support\\Facades\\Notification',
      'Password' => 'Illuminate\\Support\\Facades\\Password',
      'Queue' => 'Illuminate\\Support\\Facades\\Queue',
      'Redirect' => 'Illuminate\\Support\\Facades\\Redirect',
      'Redis' => 'Illuminate\\Support\\Facades\\Redis',
      'Request' => 'Illuminate\\Support\\Facades\\Request',
      'Response' => 'Illuminate\\Support\\Facades\\Response',
      'Route' => 'Illuminate\\Support\\Facades\\Route',
      'Schema' => 'Illuminate\\Support\\Facades\\Schema',
      'Session' => 'Illuminate\\Support\\Facades\\Session',
      'Storage' => 'Illuminate\\Support\\Facades\\Storage',
      'Str' => 'Illuminate\\Support\\Str',
      'URL' => 'Illuminate\\Support\\Facades\\URL',
      'Validator' => 'Illuminate\\Support\\Facades\\Validator',
      'View' => 'Illuminate\\Support\\Facades\\View',
      'Vimeo' => 'Vimeo\\Laravel\\Facades\\Vimeo',
      'Socialite' => 'Laravel\\Socialite\\Facades\\Socialite',
      'Metronic' => 'App\\Classes\\Theme\\Metronic',
      'Menu' => 'App\\Classes\\Theme\\Menu',
    ),
  ),
  'auth' => 
  array (
    'defaults' => 
    array (
      'guard' => 'web',
      'passwords' => 'users',
    ),
    'guards' => 
    array (
      'web' => 
      array (
        'driver' => 'session',
        'provider' => 'users',
      ),
      'user' => 
      array (
        'driver' => 'passport',
        'provider' => 'users',
      ),
      'admin' => 
      array (
        'driver' => 'session',
        'provider' => 'admins',
      ),
    ),
    'providers' => 
    array (
      'users' => 
      array (
        'driver' => 'eloquent',
        'model' => 'App\\User',
      ),
      'admins' => 
      array (
        'driver' => 'eloquent',
        'model' => 'App\\Models\\Admin',
      ),
    ),
    'passwords' => 
    array (
      'users' => 
      array (
        'provider' => 'users',
        'table' => 'password_resets',
        'expire' => 60,
        'throttle' => 60,
      ),
    ),
    'password_timeout' => 10800,
  ),
  'broadcasting' => 
  array (
    'default' => 'log',
    'connections' => 
    array (
      'pusher' => 
      array (
        'driver' => 'pusher',
        'key' => '',
        'secret' => '',
        'app_id' => '',
        'options' => 
        array (
          'cluster' => 'mt1',
          'useTLS' => true,
        ),
      ),
      'redis' => 
      array (
        'driver' => 'redis',
        'connection' => 'default',
      ),
      'log' => 
      array (
        'driver' => 'log',
      ),
      'null' => 
      array (
        'driver' => 'null',
      ),
    ),
  ),
  'cache' => 
  array (
    'default' => 'file',
    'stores' => 
    array (
      'apc' => 
      array (
        'driver' => 'apc',
      ),
      'array' => 
      array (
        'driver' => 'array',
        'serialize' => false,
      ),
      'database' => 
      array (
        'driver' => 'database',
        'table' => 'cache',
        'connection' => NULL,
      ),
      'file' => 
      array (
        'driver' => 'file',
        'path' => 'C:\\wamp64\\www\\omar\\storage\\framework/cache/data',
      ),
      'memcached' => 
      array (
        'driver' => 'memcached',
        'persistent_id' => NULL,
        'sasl' => 
        array (
          0 => NULL,
          1 => NULL,
        ),
        'options' => 
        array (
        ),
        'servers' => 
        array (
          0 => 
          array (
            'host' => '127.0.0.1',
            'port' => 11211,
            'weight' => 100,
          ),
        ),
      ),
      'redis' => 
      array (
        'driver' => 'redis',
        'connection' => 'cache',
      ),
      'dynamodb' => 
      array (
        'driver' => 'dynamodb',
        'key' => '',
        'secret' => '',
        'region' => 'us-east-1',
        'table' => 'cache',
        'endpoint' => NULL,
      ),
    ),
    'prefix' => 'omar_cache',
  ),
  'cors' => 
  array (
    'paths' => 
    array (
      0 => 'api/*',
    ),
    'allowed_methods' => 
    array (
      0 => '*',
    ),
    'allowed_origins' => 
    array (
      0 => '*',
    ),
    'allowed_origins_patterns' => 
    array (
    ),
    'allowed_headers' => 
    array (
      0 => '*',
    ),
    'exposed_headers' => false,
    'max_age' => false,
    'supports_credentials' => false,
  ),
  'database' => 
  array (
    'default' => 'mysql',
    'connections' => 
    array (
      'sqlite' => 
      array (
        'driver' => 'sqlite',
        'url' => NULL,
        'database' => 'omar',
        'prefix' => '',
        'foreign_key_constraints' => true,
      ),
      'mysql' => 
      array (
        'driver' => 'mysql',
        'url' => NULL,
        'host' => '127.0.0.1',
        'port' => '3306',
        'database' => 'omar',
        'username' => 'root',
        'password' => '',
        'unix_socket' => '',
        'charset' => 'utf8mb4',
        'collation' => 'utf8mb4_unicode_ci',
        'prefix' => '',
        'prefix_indexes' => true,
        'strict' => true,
        'engine' => NULL,
        'options' => 
        array (
        ),
      ),
      'pgsql' => 
      array (
        'driver' => 'pgsql',
        'url' => NULL,
        'host' => '127.0.0.1',
        'port' => '3306',
        'database' => 'omar',
        'username' => 'root',
        'password' => '',
        'charset' => 'utf8',
        'prefix' => '',
        'prefix_indexes' => true,
        'schema' => 'public',
        'sslmode' => 'prefer',
      ),
      'sqlsrv' => 
      array (
        'driver' => 'sqlsrv',
        'url' => NULL,
        'host' => '127.0.0.1',
        'port' => '3306',
        'database' => 'omar',
        'username' => 'root',
        'password' => '',
        'charset' => 'utf8',
        'prefix' => '',
        'prefix_indexes' => true,
      ),
    ),
    'migrations' => 'migrations',
    'redis' => 
    array (
      'client' => 'phpredis',
      'options' => 
      array (
        'cluster' => 'redis',
        'prefix' => 'omar_database_',
      ),
      'default' => 
      array (
        'url' => NULL,
        'host' => '127.0.0.1',
        'password' => NULL,
        'port' => '6379',
        'database' => '0',
      ),
      'cache' => 
      array (
        'url' => NULL,
        'host' => '127.0.0.1',
        'password' => NULL,
        'port' => '6379',
        'database' => '1',
      ),
    ),
  ),
  'filesystems' => 
  array (
    'default' => 'local',
    'cloud' => 's3',
    'disks' => 
    array (
      'local' => 
      array (
        'driver' => 'local',
        'root' => 'C:\\wamp64\\www\\omar\\storage\\app',
      ),
      'public' => 
      array (
        'driver' => 'local',
        'root' => 'C:\\wamp64\\www\\omar\\storage\\app/public',
        'url' => 'http://localhost/storage',
        'visibility' => 'public',
      ),
      's3' => 
      array (
        'driver' => 's3',
        'key' => '',
        'secret' => '',
        'region' => 'us-east-1',
        'bucket' => '',
        'url' => NULL,
      ),
    ),
    'links' => 
    array (
      'C:\\wamp64\\www\\omar\\public\\storage' => 'C:\\wamp64\\www\\omar\\storage\\app/public',
    ),
  ),
  'hashing' => 
  array (
    'driver' => 'bcrypt',
    'bcrypt' => 
    array (
      'rounds' => 10,
    ),
    'argon' => 
    array (
      'memory' => 1024,
      'threads' => 2,
      'time' => 2,
    ),
  ),
  'layout' => 
  array (
    'self' => 
    array (
      'layout' => 'default',
      'rtl' => true,
    ),
    'js' => 
    array (
      'breakpoints' => 
      array (
        'sm' => 576,
        'md' => 768,
        'lg' => 992,
        'xl' => 1200,
        'xxl' => 1200,
      ),
      'colors' => 
      array (
        'theme' => 
        array (
          'base' => 
          array (
            'white' => '#ffffff',
            'primary' => '#6993FF',
            'secondary' => '#E5EAEE',
            'success' => '#1BC5BD',
            'info' => '#8950FC',
            'warning' => '#FFA800',
            'danger' => '#F64E60',
            'light' => '#F3F6F9',
            'dark' => '#212121',
          ),
          'light' => 
          array (
            'white' => '#ffffff',
            'primary' => '#E1E9FF',
            'secondary' => '#ECF0F3',
            'success' => '#C9F7F5',
            'info' => '#EEE5FF',
            'warning' => '#FFF4DE',
            'danger' => '#FFE2E5',
            'light' => '#F3F6F9',
            'dark' => '#D6D6E0',
          ),
          'inverse' => 
          array (
            'white' => '#ffffff',
            'primary' => '#ffffff',
            'secondary' => '#212121',
            'success' => '#ffffff',
            'info' => '#ffffff',
            'warning' => '#ffffff',
            'danger' => '#ffffff',
            'light' => '#464E5F',
            'dark' => '#ffffff',
          ),
        ),
        'gray' => 
        array (
          'gray-100' => '#F3F6F9',
          'gray-200' => '#ECF0F3',
          'gray-300' => '#E5EAEE',
          'gray-400' => '#D6D6E0',
          'gray-500' => '#B5B5C3',
          'gray-600' => '#80808F',
          'gray-700' => '#464E5F',
          'gray-800' => '#1B283F',
          'gray-900' => '#212121',
        ),
      ),
      'font-family' => 'Tajawal',
    ),
    'page-loader' => 
    array (
      'type' => '',
    ),
    'header' => 
    array (
      'self' => 
      array (
        'display' => true,
        'width' => 'fluid',
        'theme' => 'light',
        'fixed' => 
        array (
          'desktop' => true,
          'mobile' => true,
        ),
      ),
      'menu' => 
      array (
        'self' => 
        array (
          'display' => true,
          'layout' => 'default',
          'root-arrow' => false,
        ),
        'desktop' => 
        array (
          'arrow' => true,
          'toggle' => 'click',
          'submenu' => 
          array (
            'theme' => 'light',
            'arrow' => true,
          ),
        ),
        'mobile' => 
        array (
          'submenu' => 
          array (
            'theme' => 'dark',
            'accordion' => true,
          ),
        ),
      ),
    ),
    'subheader' => 
    array (
      'display' => true,
      'displayDesc' => true,
      'layout' => 'subheader-v1',
      'fixed' => true,
      'width' => 'fluid',
      'clear' => false,
      'layouts' => 
      array (
        'subheader-v1' => 'Subheader v1',
        'subheader-v2' => 'Subheader v2',
        'subheader-v3' => 'Subheader v3',
        'subheader-v4' => 'Subheader v4',
      ),
      'style' => 'solid',
    ),
    'content' => 
    array (
      'width' => 'fixed',
      'extended' => false,
    ),
    'brand' => 
    array (
      'self' => 
      array (
        'theme' => 'dark',
      ),
    ),
    'aside' => 
    array (
      'self' => 
      array (
        'theme' => 'dark',
        'display' => true,
        'fixed' => true,
        'minimize' => 
        array (
          'toggle' => true,
          'default' => false,
          'hoverable' => true,
        ),
      ),
      'menu' => 
      array (
        'dropdown' => false,
        'scroll' => false,
        'submenu' => 
        array (
          'accordion' => true,
          'dropdown' => 
          array (
            'arrow' => true,
            'hover-timeout' => 500,
          ),
        ),
      ),
    ),
    'footer' => 
    array (
      'width' => 'fluid',
      'fixed' => false,
    ),
    'extras' => 
    array (
      'search' => 
      array (
        'display' => true,
        'layout' => 'dropdown',
        'offcanvas' => 
        array (
          'direction' => 'right',
        ),
      ),
      'notifications' => 
      array (
        'display' => true,
        'layout' => 'dropdown',
        'dropdown' => 
        array (
          'style' => 'dark',
        ),
        'offcanvas' => 
        array (
          'direction' => 'right',
        ),
      ),
      'quick-actions' => 
      array (
        'display' => true,
        'layout' => 'dropdown',
        'dropdown' => 
        array (
          'style' => 'dark',
        ),
        'offcanvas' => 
        array (
          'direction' => 'right',
        ),
      ),
      'user' => 
      array (
        'display' => true,
        'layout' => 'offcanvas',
        'dropdown' => 
        array (
          'style' => 'dark',
        ),
        'offcanvas' => 
        array (
          'direction' => 'right',
        ),
      ),
      'languages' => 
      array (
        'display' => true,
      ),
      'cart' => 
      array (
        'display' => true,
        'dropdown' => 
        array (
          'style' => 'dark',
        ),
      ),
      'quick-panel' => 
      array (
        'display' => true,
        'offcanvas' => 
        array (
          'direction' => 'right',
        ),
      ),
      'chat' => 
      array (
        'display' => true,
      ),
      'toolbar' => 
      array (
        'display' => true,
      ),
      'scrolltop' => 
      array (
        'display' => true,
      ),
    ),
    'resources' => 
    array (
      'favicon' => 'media/img/logo/favicon.ico',
      'fonts' => 
      array (
        'google' => 
        array (
          'families' => 
          array (
            0 => 'Tajawal:300,400,500,600,700',
          ),
        ),
      ),
      'css' => 
      array (
        0 => 'plugins/global/plugins.bundle.css',
        1 => 'plugins/custom/prismjs/prismjs.bundle.css',
        2 => 'css/style.bundle.css',
      ),
      'js' => 
      array (
        0 => 'plugins/global/plugins.bundle.js',
        1 => 'plugins/custom/prismjs/prismjs.bundle.js',
        2 => 'js/scripts.bundle.js',
      ),
    ),
  ),
  'logging' => 
  array (
    'default' => 'stack',
    'channels' => 
    array (
      'stack' => 
      array (
        'driver' => 'stack',
        'channels' => 
        array (
          0 => 'single',
        ),
        'ignore_exceptions' => false,
      ),
      'single' => 
      array (
        'driver' => 'single',
        'path' => 'C:\\wamp64\\www\\omar\\storage\\logs/laravel.log',
        'level' => 'debug',
      ),
      'daily' => 
      array (
        'driver' => 'daily',
        'path' => 'C:\\wamp64\\www\\omar\\storage\\logs/laravel.log',
        'level' => 'debug',
        'days' => 14,
      ),
      'slack' => 
      array (
        'driver' => 'slack',
        'url' => NULL,
        'username' => 'Laravel Log',
        'emoji' => ':boom:',
        'level' => 'critical',
      ),
      'papertrail' => 
      array (
        'driver' => 'monolog',
        'level' => 'debug',
        'handler' => 'Monolog\\Handler\\SyslogUdpHandler',
        'handler_with' => 
        array (
          'host' => NULL,
          'port' => NULL,
        ),
      ),
      'stderr' => 
      array (
        'driver' => 'monolog',
        'handler' => 'Monolog\\Handler\\StreamHandler',
        'formatter' => NULL,
        'with' => 
        array (
          'stream' => 'php://stderr',
        ),
      ),
      'syslog' => 
      array (
        'driver' => 'syslog',
        'level' => 'debug',
      ),
      'errorlog' => 
      array (
        'driver' => 'errorlog',
        'level' => 'debug',
      ),
      'null' => 
      array (
        'driver' => 'monolog',
        'handler' => 'Monolog\\Handler\\NullHandler',
      ),
      'emergency' => 
      array (
        'path' => 'C:\\wamp64\\www\\omar\\storage\\logs/laravel.log',
      ),
    ),
  ),
  'mail' => 
  array (
    'default' => 'smtp',
    'mailers' => 
    array (
      'smtp' => 
      array (
        'transport' => 'smtp',
        'host' => 'mailhog',
        'port' => '1025',
        'encryption' => NULL,
        'username' => NULL,
        'password' => NULL,
      ),
      'ses' => 
      array (
        'transport' => 'ses',
      ),
      'mailgun' => 
      array (
        'transport' => 'mailgun',
      ),
      'postmark' => 
      array (
        'transport' => 'postmark',
      ),
      'sendmail' => 
      array (
        'transport' => 'sendmail',
        'path' => '/usr/sbin/sendmail -bs',
      ),
      'log' => 
      array (
        'transport' => 'log',
        'channel' => NULL,
      ),
      'array' => 
      array (
        'transport' => 'array',
      ),
    ),
    'from' => 
    array (
      'address' => NULL,
      'name' => 'omar',
    ),
    'markdown' => 
    array (
      'theme' => 'default',
      'paths' => 
      array (
        0 => 'C:\\wamp64\\www\\omar\\resources\\views/vendor/mail',
      ),
    ),
  ),
  'menu_aside' => 
  array (
    'items' => 
    array (
      0 => 
      array (
        'title' => 'Dashboard',
        'root' => true,
        'icon' => 'media/svg/icons/Design/Layers.svg',
        'page' => '/',
        'new-tab' => false,
      ),
      1 => 
      array (
        'section' => 'Custom',
      ),
      2 => 
      array (
        'title' => 'Applications',
        'icon' => 'media/svg/icons/Layout/Layout-4-blocks.svg',
        'bullet' => 'line',
        'root' => true,
        'submenu' => 
        array (
          0 => 
          array (
            'title' => 'Users',
            'bullet' => 'dot',
            'submenu' => 
            array (
              0 => 
              array (
                'title' => 'List - Default',
                'page' => 'test',
              ),
              1 => 
              array (
                'title' => 'List - Datatable',
                'page' => 'custom/apps/user/list-datatable',
              ),
              2 => 
              array (
                'title' => 'List - Columns 1',
                'page' => 'custom/apps/user/list-columns-1',
              ),
              3 => 
              array (
                'title' => 'List - Columns 2',
                'page' => 'custom/apps/user/list-columns-2',
              ),
              4 => 
              array (
                'title' => 'Add User',
                'page' => 'custom/apps/user/add-user',
              ),
              5 => 
              array (
                'title' => 'Edit User',
                'page' => 'custom/apps/user/edit-user',
              ),
            ),
          ),
          1 => 
          array (
            'title' => 'Profile',
            'bullet' => 'dot',
            'submenu' => 
            array (
              0 => 
              array (
                'title' => 'Profile 1',
                'bullet' => 'line',
                'submenu' => 
                array (
                  0 => 
                  array (
                    'title' => 'Overview',
                    'page' => 'custom/apps/profile/profile-1/overview',
                  ),
                  1 => 
                  array (
                    'title' => 'Personal Information',
                    'page' => 'custom/apps/profile/profile-1/personal-information',
                  ),
                  2 => 
                  array (
                    'title' => 'Account Information',
                    'page' => 'custom/apps/profile/profile-1/account-information',
                  ),
                  3 => 
                  array (
                    'title' => 'Change Password',
                    'page' => 'custom/apps/profile/profile-1/change-password',
                  ),
                  4 => 
                  array (
                    'title' => 'Email Settings',
                    'page' => 'custom/apps/profile/profile-1/email-settings',
                  ),
                ),
              ),
              1 => 
              array (
                'title' => 'Profile 2',
                'page' => 'custom/apps/profile/profile-2',
              ),
              2 => 
              array (
                'title' => 'Profile 3',
                'page' => 'custom/apps/profile/profile-3',
              ),
              3 => 
              array (
                'title' => 'Profile 4',
                'page' => 'custom/apps/profile/profile-4',
              ),
            ),
          ),
          2 => 
          array (
            'title' => 'Contacts',
            'bullet' => 'dot',
            'submenu' => 
            array (
              0 => 
              array (
                'title' => 'List - Columns',
                'page' => 'custom/apps/contacts/list-columns',
              ),
              1 => 
              array (
                'title' => 'List - Datatable',
                'page' => 'custom/apps/contacts/list-datatable',
              ),
              2 => 
              array (
                'title' => 'View Contact',
                'page' => 'custom/apps/contacts/view-contact',
              ),
              3 => 
              array (
                'title' => 'Add Contact',
                'page' => 'custom/apps/contacts/add-contact',
              ),
              4 => 
              array (
                'title' => 'Edit Contact',
                'page' => 'custom/apps/contacts/edit-contact',
              ),
            ),
          ),
          3 => 
          array (
            'title' => 'Projects',
            'bullet' => 'dot',
            'submenu' => 
            array (
              0 => 
              array (
                'title' => 'List - Columns 1',
                'page' => 'custom/apps/projects/list-columns-1',
              ),
              1 => 
              array (
                'title' => 'List - Columns 2',
                'page' => 'custom/apps/projects/list-columns-2',
              ),
              2 => 
              array (
                'title' => 'List - Columns 3',
                'page' => 'custom/apps/projects/list-columns-3',
              ),
              3 => 
              array (
                'title' => 'List - Columns 4',
                'page' => 'custom/apps/projects/list-columns-4',
              ),
              4 => 
              array (
                'title' => 'List - Datatable',
                'page' => 'custom/apps/projects/list-datatable',
              ),
              5 => 
              array (
                'title' => 'View Project',
                'page' => 'custom/apps/projects/view-project',
              ),
              6 => 
              array (
                'title' => 'Add Project',
                'page' => 'custom/apps/projects/add-project',
              ),
              7 => 
              array (
                'title' => 'Edit Project',
                'page' => 'custom/apps/projects/edit-project',
              ),
            ),
          ),
          4 => 
          array (
            'title' => 'Support Center',
            'bullet' => 'dot',
            'submenu' => 
            array (
              0 => 
              array (
                'title' => 'Home 1',
                'page' => 'custom/apps/support-center/home-1',
              ),
              1 => 
              array (
                'title' => 'Home 2',
                'page' => 'custom/apps/support-center/home-2',
              ),
              2 => 
              array (
                'title' => 'FAQ 1',
                'page' => 'custom/apps/support-center/faq-1',
              ),
              3 => 
              array (
                'title' => 'FAQ 2',
                'page' => 'custom/apps/support-center/faq-2',
              ),
              4 => 
              array (
                'title' => 'FAQ 3',
                'page' => 'custom/apps/support-center/faq-3',
              ),
              5 => 
              array (
                'title' => 'Feedback',
                'page' => 'custom/apps/support-center/feedback',
              ),
              6 => 
              array (
                'title' => 'License',
                'page' => 'custom/apps/support-center/license',
              ),
            ),
          ),
          5 => 
          array (
            'title' => 'Chat',
            'bullet' => 'dot',
            'submenu' => 
            array (
              0 => 
              array (
                'title' => 'Private',
                'page' => 'custom/apps/chat/private',
              ),
              1 => 
              array (
                'title' => 'Group',
                'page' => 'custom/apps/chat/group',
              ),
              2 => 
              array (
                'title' => 'Popup',
                'page' => 'custom/apps/chat/popup',
              ),
            ),
          ),
          6 => 
          array (
            'title' => 'Todo',
            'bullet' => 'dot',
            'submenu' => 
            array (
              0 => 
              array (
                'title' => 'Tasks',
                'page' => 'custom/apps/todo/tasks',
              ),
              1 => 
              array (
                'title' => 'Docs',
                'page' => 'custom/apps/todo/docs',
              ),
              2 => 
              array (
                'title' => 'Files',
                'page' => 'custom/apps/todo/files',
              ),
            ),
          ),
          7 => 
          array (
            'title' => 'Inbox',
            'bullet' => 'dot',
            'page' => 'custom/apps/inbox',
            'label' => 
            array (
              'type' => 'label-danger label-inline',
              'value' => 'new',
            ),
          ),
        ),
      ),
      3 => 
      array (
        'title' => 'Pages',
        'icon' => 'media/svg/icons/Shopping/Barcode-read.svg',
        'bullet' => 'dot',
        'root' => true,
        'submenu' => 
        array (
          0 => 
          array (
            'title' => 'Wizard',
            'bullet' => 'dot',
            'submenu' => 
            array (
              0 => 
              array (
                'title' => 'Wizard 1',
                'page' => 'custom/pages/wizard/wizard-1',
              ),
              1 => 
              array (
                'title' => 'Wizard 2',
                'page' => 'custom/pages/wizard/wizard-2',
              ),
              2 => 
              array (
                'title' => 'Wizard 3',
                'page' => 'custom/pages/wizard/wizard-3',
              ),
              3 => 
              array (
                'title' => 'Wizard 4',
                'page' => 'custom/pages/wizard/wizard-4',
              ),
            ),
          ),
          1 => 
          array (
            'title' => 'Pricing Tables',
            'bullet' => 'dot',
            'submenu' => 
            array (
              0 => 
              array (
                'title' => 'Pricing Tables 1',
                'page' => 'custom/pages/pricing/pricing-1',
              ),
              1 => 
              array (
                'title' => 'Pricing Tables 2',
                'page' => 'custom/pages/pricing/pricing-2',
              ),
              2 => 
              array (
                'title' => 'Pricing Tables 3',
                'page' => 'custom/pages/pricing/pricing-3',
              ),
              3 => 
              array (
                'title' => 'Pricing Tables 4',
                'page' => 'custom/pages/pricing/pricing-4',
              ),
            ),
          ),
          2 => 
          array (
            'title' => 'Invoices',
            'bullet' => 'dot',
            'submenu' => 
            array (
              0 => 
              array (
                'title' => 'Invoice 1',
                'page' => 'custom/pages/invoices/invoice-1',
              ),
              1 => 
              array (
                'title' => 'Invoice 2',
                'page' => 'custom/pages/invoices/invoice-2',
              ),
            ),
          ),
          3 => 
          array (
            'title' => 'User Pages',
            'bullet' => 'dot',
            'label' => 
            array (
              'type' => 'label-rounded label-primary',
              'value' => '2',
            ),
            'submenu' => 
            array (
              0 => 
              array (
                'title' => 'Login 1',
                'page' => 'custom/pages/users/login-1',
                'new-tab' => true,
              ),
              1 => 
              array (
                'title' => 'Login 2',
                'page' => 'custom/pages/users/login-2',
                'new-tab' => true,
              ),
              2 => 
              array (
                'title' => 'Login 3',
                'page' => 'custom/pages/users/login-3',
                'new-tab' => true,
              ),
              3 => 
              array (
                'title' => 'Login 4',
                'page' => 'custom/pages/users/login-4',
                'new-tab' => true,
              ),
              4 => 
              array (
                'title' => 'Login 5',
                'page' => 'custom/pages/users/login-5',
                'new-tab' => true,
              ),
              5 => 
              array (
                'title' => 'Login 6',
                'page' => 'custom/pages/users/login-6',
                'new-tab' => true,
              ),
            ),
          ),
          4 => 
          array (
            'title' => 'Error Pages',
            'bullet' => 'dot',
            'submenu' => 
            array (
              0 => 
              array (
                'title' => 'Error 1',
                'page' => 'custom/pages/errors/error-1',
                'new-tab' => true,
              ),
              1 => 
              array (
                'title' => 'Error 2',
                'page' => 'custom/pages/errors/error-2',
                'new-tab' => true,
              ),
              2 => 
              array (
                'title' => 'Error 3',
                'page' => 'custom/pages/errors/error-3',
                'new-tab' => true,
              ),
              3 => 
              array (
                'title' => 'Error 4',
                'page' => 'custom/pages/errors/error-4',
                'new-tab' => true,
              ),
              4 => 
              array (
                'title' => 'Error 5',
                'page' => 'custom/pages/errors/error-5',
                'new-tab' => true,
              ),
              5 => 
              array (
                'title' => 'Error 6',
                'page' => 'custom/pages/errors/error-6',
                'new-tab' => true,
              ),
            ),
          ),
        ),
      ),
      4 => 
      array (
        'section' => 'Layout',
      ),
      5 => 
      array (
        'title' => 'Themes',
        'desc' => '',
        'icon' => 'media/svg/icons/Design/Bucket.svg',
        'bullet' => 'dot',
        'root' => true,
        'submenu' => 
        array (
          0 => 
          array (
            'title' => 'Light Aside',
            'page' => 'layout/themes/aside-light',
          ),
          1 => 
          array (
            'title' => 'Dark Header',
            'page' => 'layout/themes/header-dark',
          ),
        ),
      ),
      6 => 
      array (
        'title' => 'Subheaders',
        'desc' => '',
        'icon' => 'media/svg/icons/Code/Compiling.svg',
        'bullet' => 'dot',
        'root' => true,
        'submenu' => 
        array (
          0 => 
          array (
            'title' => 'Toolbar Nav',
            'page' => 'layout/subheader/toolbar',
          ),
          1 => 
          array (
            'title' => 'Actions Buttons',
            'page' => 'layout/subheader/actions',
          ),
          2 => 
          array (
            'title' => 'Tabbed Nav',
            'page' => 'layout/subheader/tabbed',
          ),
          3 => 
          array (
            'title' => 'Classic',
            'page' => 'layout/subheader/classic',
          ),
          4 => 
          array (
            'title' => 'None',
            'page' => 'layout/subheader/none',
          ),
        ),
      ),
      7 => 
      array (
        'title' => 'General',
        'icon' => 'media/svg/icons/General/Settings-1.svg',
        'bullet' => 'dot',
        'root' => true,
        'submenu' => 
        array (
          0 => 
          array (
            'title' => 'Fixed Content',
            'page' => 'layout/general/fixed-content',
          ),
          1 => 
          array (
            'title' => 'Minimized Aside',
            'page' => 'layout/general/minimized-aside',
          ),
          2 => 
          array (
            'title' => 'No Aside',
            'page' => 'layout/general/no-aside',
          ),
          3 => 
          array (
            'title' => 'Empty Page',
            'page' => 'layout/general/empty-page',
          ),
          4 => 
          array (
            'title' => 'Fixed Footer',
            'page' => 'layout/general/fixed-footer',
          ),
          5 => 
          array (
            'title' => 'No Header Menu',
            'page' => 'layout/general/no-header-menu',
          ),
        ),
      ),
      8 => 
      array (
        'title' => 'Builder',
        'root' => true,
        'icon' => 'media/svg/icons/Home/Library.svg',
        'page' => 'builder',
        'visible' => 'preview',
      ),
      9 => 
      array (
        'section' => 'CRUD',
      ),
      10 => 
      array (
        'title' => 'Forms',
        'icon' => 'media/svg/icons/Design/PenAndRuller.svg',
        'root' => true,
        'bullet' => 'dot',
        'submenu' => 
        array (
          0 => 
          array (
            'title' => 'Form Controls',
            'desc' => '',
            'icon' => 'flaticon-interface-3',
            'bullet' => 'dot',
            'submenu' => 
            array (
              0 => 
              array (
                'title' => 'Base Inputs',
                'page' => 'crud/forms/controls/base',
              ),
              1 => 
              array (
                'title' => 'Input Groups',
                'page' => 'crud/forms/controls/input-group',
              ),
              2 => 
              array (
                'title' => 'Checkbox',
                'page' => 'crud/forms/controls/checkbox',
              ),
              3 => 
              array (
                'title' => 'Radio',
                'page' => 'crud/forms/controls/radio',
              ),
              4 => 
              array (
                'title' => 'Switch',
                'page' => 'crud/forms/controls/switch',
              ),
              5 => 
              array (
                'title' => 'Mega Options',
                'page' => 'crud/forms/controls/option',
              ),
            ),
          ),
          1 => 
          array (
            'title' => 'Form Widgets',
            'desc' => '',
            'icon' => 'flaticon-interface-1',
            'bullet' => 'dot',
            'submenu' => 
            array (
              0 => 
              array (
                'title' => 'Datepicker',
                'page' => 'crud/forms/widgets/bootstrap-datepicker',
              ),
              1 => 
              array (
                'title' => 'Datetimepicker',
                'page' => 'crud/forms/widgets/bootstrap-datetimepicker',
              ),
              2 => 
              array (
                'title' => 'Timepicker',
                'page' => 'crud/forms/widgets/bootstrap-timepicker',
              ),
              3 => 
              array (
                'title' => 'Daterangepicker',
                'page' => 'crud/forms/widgets/bootstrap-daterangepicker',
              ),
              4 => 
              array (
                'title' => 'Tagify',
                'page' => 'crud/forms/widgets/tagify',
              ),
              5 => 
              array (
                'title' => 'Touchspin',
                'page' => 'crud/forms/widgets/bootstrap-touchspin',
              ),
              6 => 
              array (
                'title' => 'Maxlength',
                'page' => 'crud/forms/widgets/bootstrap-maxlength',
              ),
              7 => 
              array (
                'title' => 'Switch',
                'page' => 'crud/forms/widgets/bootstrap-switch',
              ),
              8 => 
              array (
                'title' => 'Multiple Select Splitter',
                'page' => 'crud/forms/widgets/bootstrap-multipleselectsplitter',
              ),
              9 => 
              array (
                'title' => 'Bootstrap Select',
                'page' => 'crud/forms/widgets/bootstrap-select',
              ),
              10 => 
              array (
                'title' => 'Select2',
                'page' => 'crud/forms/widgets/select2',
              ),
              11 => 
              array (
                'title' => 'Typeahead',
                'page' => 'crud/forms/widgets/typeahead',
              ),
              12 => 
              array (
                'title' => 'noUiSlider',
                'page' => 'crud/forms/widgets/nouislider',
              ),
              13 => 
              array (
                'title' => 'Form Repeater',
                'page' => 'crud/forms/widgets/form-repeater',
              ),
              14 => 
              array (
                'title' => 'Ion Range Slider',
                'page' => 'crud/forms/widgets/ion-range-slider',
              ),
              15 => 
              array (
                'title' => 'Input Masks',
                'page' => 'crud/forms/widgets/input-mask',
              ),
              16 => 
              array (
                'title' => 'Autosize',
                'page' => 'crud/forms/widgets/autosize',
              ),
              17 => 
              array (
                'title' => 'Clipboard',
                'page' => 'crud/forms/widgets/clipboard',
              ),
              18 => 
              array (
                'title' => 'Google reCaptcha',
                'page' => 'crud/forms/widgets/recaptcha',
              ),
            ),
          ),
          2 => 
          array (
            'title' => 'Form Text Editors',
            'desc' => '',
            'icon' => 'flaticon-interface-1',
            'bullet' => 'dot',
            'submenu' => 
            array (
              0 => 
              array (
                'title' => 'TinyMCE',
                'page' => 'crud/forms/editors/tinymce',
              ),
              1 => 
              array (
                'title' => 'CKEditor',
                'bullet' => 'line',
                'submenu' => 
                array (
                  0 => 
                  array (
                    'title' => 'CKEditor Classic',
                    'page' => 'crud/forms/editors/ckeditor-classic',
                  ),
                  1 => 
                  array (
                    'title' => 'CKEditor Inline',
                    'page' => 'crud/forms/editors/ckeditor-inline',
                  ),
                  2 => 
                  array (
                    'title' => 'CKEditor Balloon',
                    'page' => 'crud/forms/editors/ckeditor-balloon',
                  ),
                  3 => 
                  array (
                    'title' => 'CKEditor Balloon Block',
                    'page' => 'crud/forms/editors/ckeditor-balloon-block',
                  ),
                  4 => 
                  array (
                    'title' => 'CKEditor Document',
                    'page' => 'crud/forms/editors/ckeditor-document',
                  ),
                ),
              ),
              2 => 
              array (
                'title' => 'Quill Text Editor',
                'page' => 'crud/forms/editors/quill',
              ),
              3 => 
              array (
                'title' => 'Summernote WYSIWYG',
                'page' => 'crud/forms/editors/summernote',
              ),
              4 => 
              array (
                'title' => 'Markdown Editor',
                'page' => 'crud/forms/editors/bootstrap-markdown',
              ),
            ),
          ),
          3 => 
          array (
            'title' => 'Form Layouts',
            'desc' => '',
            'icon' => 'flaticon-web',
            'bullet' => 'dot',
            'submenu' => 
            array (
              0 => 
              array (
                'title' => 'Default Forms',
                'page' => 'crud/forms/layouts/default-forms',
              ),
              1 => 
              array (
                'title' => 'Multi Column Forms',
                'page' => 'crud/forms/layouts/multi-column-forms',
              ),
              2 => 
              array (
                'title' => 'Basic Action Bars',
                'page' => 'crud/forms/layouts/action-bars',
              ),
              3 => 
              array (
                'title' => 'Sticky Action Bar',
                'page' => 'crud/forms/layouts/sticky-action-bar',
              ),
            ),
          ),
          4 => 
          array (
            'title' => 'Form Validation',
            'desc' => '',
            'icon' => 'flaticon-calendar-2',
            'bullet' => 'dot',
            'submenu' => 
            array (
              0 => 
              array (
                'title' => 'Validation States',
                'page' => 'crud/forms/validation/states',
              ),
              1 => 
              array (
                'title' => 'Form Controls',
                'page' => 'crud/forms/validation/form-controls',
              ),
              2 => 
              array (
                'title' => 'Form Widgets',
                'page' => 'crud/forms/validation/form-widgets',
              ),
            ),
          ),
        ),
      ),
      11 => 
      array (
        'title' => 'KTDatatable',
        'icon' => 'media/svg/icons/Layout/Layout-left-panel-2.svg',
        'bullet' => 'dot',
        'root' => true,
        'submenu' => 
        array (
          0 => 
          array (
            'title' => 'Base',
            'desc' => '',
            'bullet' => 'dot',
            'submenu' => 
            array (
              0 => 
              array (
                'title' => 'Local Data',
                'page' => 'crud/ktdatatable/base/data-local',
                'icon' => '',
              ),
              1 => 
              array (
                'title' => 'JSON Data',
                'page' => 'crud/ktdatatable/base/data-json',
                'icon' => '',
              ),
              2 => 
              array (
                'title' => 'Ajax Data',
                'page' => 'crud/ktdatatable/base/data-ajax',
                'icon' => '',
              ),
              3 => 
              array (
                'title' => 'HTML Table',
                'page' => 'crud/ktdatatable/base/html-table',
                'icon' => '',
              ),
              4 => 
              array (
                'title' => 'Local Sort',
                'page' => 'crud/ktdatatable/base/local-sort',
                'icon' => '',
              ),
              5 => 
              array (
                'title' => 'Translation',
                'page' => 'crud/ktdatatable/base/translation',
                'icon' => '',
              ),
            ),
          ),
          1 => 
          array (
            'title' => 'Advanced',
            'desc' => '',
            'bullet' => 'dot',
            'submenu' => 
            array (
              0 => 
              array (
                'title' => 'Record Selection',
                'page' => 'crud/ktdatatable/advanced/record-selection',
                'icon' => '',
              ),
              1 => 
              array (
                'title' => 'Row Details',
                'page' => 'crud/ktdatatable/advanced/row-details',
                'icon' => '',
              ),
              2 => 
              array (
                'title' => 'Modal Examples',
                'page' => 'crud/ktdatatable/advanced/modal',
                'icon' => '',
              ),
              3 => 
              array (
                'title' => 'Column Rendering',
                'page' => 'crud/ktdatatable/advanced/column-rendering',
                'icon' => '',
              ),
              4 => 
              array (
                'title' => 'Column Width',
                'page' => 'crud/ktdatatable/advanced/column-width',
                'icon' => '',
              ),
              5 => 
              array (
                'title' => 'Vertical Scrolling',
                'page' => 'crud/ktdatatable/advanced/vertical',
                'icon' => '',
              ),
            ),
          ),
          2 => 
          array (
            'title' => 'Child Datatables',
            'desc' => '',
            'bullet' => 'dot',
            'submenu' => 
            array (
              0 => 
              array (
                'title' => 'Local Data',
                'page' => 'crud/ktdatatable/child/data-local',
                'icon' => '',
              ),
              1 => 
              array (
                'title' => 'Remote Data',
                'page' => 'crud/ktdatatable/child/data-ajax',
                'icon' => '',
              ),
            ),
          ),
          3 => 
          array (
            'title' => 'API',
            'desc' => '',
            'bullet' => 'dot',
            'submenu' => 
            array (
              0 => 
              array (
                'title' => 'API Methods',
                'page' => 'crud/ktdatatable/api/methods',
                'icon' => '',
              ),
              1 => 
              array (
                'title' => 'Events',
                'page' => 'crud/ktdatatable/api/events',
                'icon' => '',
              ),
            ),
          ),
        ),
      ),
      12 => 
      array (
        'title' => 'Datatables.net',
        'icon' => 'media/svg/icons/Layout/Layout-horizontal.svg',
        'bullet' => 'dot',
        'root' => true,
        'submenu' => 
        array (
          0 => 
          array (
            'title' => 'Basic',
            'desc' => '',
            'bullet' => 'dot',
            'submenu' => 
            array (
              0 => 
              array (
                'title' => 'Basic Tables',
                'page' => 'crud/datatables/basic/basic',
              ),
              1 => 
              array (
                'title' => 'Scrollable Tables',
                'page' => 'crud/datatables/basic/scrollable',
              ),
              2 => 
              array (
                'title' => 'Complex Headers',
                'page' => 'crud/datatables/basic/headers',
              ),
              3 => 
              array (
                'title' => 'Pagination Options',
                'page' => 'crud/datatables/basic/paginations',
              ),
            ),
          ),
          1 => 
          array (
            'title' => 'Advanced',
            'desc' => '',
            'bullet' => 'dot',
            'submenu' => 
            array (
              0 => 
              array (
                'title' => 'Column Rendering',
                'page' => 'crud/datatables/advanced/column-rendering',
              ),
              1 => 
              array (
                'title' => 'Multiple Controls',
                'page' => 'crud/datatables/advanced/multiple-controls',
              ),
              2 => 
              array (
                'title' => 'Column Visibility',
                'page' => 'crud/datatables/advanced/column-visibility',
              ),
              3 => 
              array (
                'title' => 'Row Callback',
                'page' => 'crud/datatables/advanced/row-callback',
              ),
              4 => 
              array (
                'title' => 'Row Grouping',
                'page' => 'crud/datatables/advanced/row-grouping',
              ),
              5 => 
              array (
                'title' => 'Footer Callback',
                'page' => 'crud/datatables/advanced/footer-callback',
              ),
            ),
          ),
          2 => 
          array (
            'title' => 'Data sources',
            'desc' => '',
            'bullet' => 'dot',
            'submenu' => 
            array (
              0 => 
              array (
                'title' => 'HTML',
                'page' => 'crud/datatables/data-sources/html',
              ),
              1 => 
              array (
                'title' => 'Javascript',
                'page' => 'crud/datatables/data-sources/javascript',
              ),
              2 => 
              array (
                'title' => 'Ajax Client-side',
                'page' => 'crud/datatables/data-sources/ajax-client-side',
              ),
              3 => 
              array (
                'title' => 'Ajax Server-side',
                'page' => 'crud/datatables/data-sources/ajax-server-side',
              ),
            ),
          ),
          3 => 
          array (
            'title' => 'Search Options',
            'desc' => '',
            'bullet' => 'dot',
            'submenu' => 
            array (
              0 => 
              array (
                'title' => 'Column Search',
                'page' => 'crud/datatables/search-options/column-search',
              ),
              1 => 
              array (
                'title' => 'Advanced Search',
                'page' => 'crud/datatables/search-options/advanced-search',
              ),
            ),
          ),
          4 => 
          array (
            'title' => 'Extensions',
            'desc' => '',
            'bullet' => 'dot',
            'submenu' => 
            array (
              0 => 
              array (
                'title' => 'Buttons',
                'page' => 'crud/datatables/extensions/buttons',
              ),
              1 => 
              array (
                'title' => 'ColReorder',
                'page' => 'crud/datatables/extensions/colreorder',
              ),
              2 => 
              array (
                'title' => 'KeyTable',
                'page' => 'crud/datatables/extensions/keytable',
              ),
              3 => 
              array (
                'title' => 'Responsive',
                'page' => 'crud/datatables/extensions/responsive',
              ),
              4 => 
              array (
                'title' => 'RowGroup',
                'page' => 'crud/datatables/extensions/rowgroup',
              ),
              5 => 
              array (
                'title' => 'RowReorder',
                'page' => 'crud/datatables/extensions/rowreorder',
              ),
              6 => 
              array (
                'title' => 'Scroller',
                'page' => 'crud/datatables/extensions/scroller',
              ),
              7 => 
              array (
                'title' => 'Select',
                'page' => 'crud/datatables/extensions/select',
              ),
            ),
          ),
        ),
      ),
      13 => 
      array (
        'title' => 'File Upload',
        'desc' => '',
        'icon' => 'media/svg/icons/Files/Upload.svg',
        'bullet' => 'dot',
        'submenu' => 
        array (
          0 => 
          array (
            'title' => 'Image Input',
            'page' => 'crud/file-upload/image-input',
          ),
          1 => 
          array (
            'title' => 'DropzoneJS',
            'page' => 'crud/file-upload/dropzonejs',
            'label' => 
            array (
              'type' => 'label-danger label-inline',
              'value' => 'new',
            ),
          ),
          2 => 
          array (
            'title' => 'Uppy',
            'page' => 'crud/file-upload/uppy',
          ),
        ),
      ),
      14 => 
      array (
        'section' => 'Features',
      ),
      15 => 
      array (
        'title' => 'Bootstrap',
        'icon' => 'media/svg/icons/Shopping/Box2.svg',
        'bullet' => 'dot',
        'root' => true,
        'submenu' => 
        array (
          0 => 
          array (
            'title' => 'Typography',
            'page' => 'features/bootstrap/typography',
          ),
          1 => 
          array (
            'title' => 'Buttons',
            'page' => 'features/bootstrap/buttons',
          ),
          2 => 
          array (
            'title' => 'Button Group',
            'page' => 'features/bootstrap/button-group',
          ),
          3 => 
          array (
            'title' => 'Dropdown',
            'page' => 'features/bootstrap/dropdown',
          ),
          4 => 
          array (
            'title' => 'Navs',
            'page' => 'features/bootstrap/navs',
          ),
          5 => 
          array (
            'title' => 'Tables',
            'page' => 'features/bootstrap/tables',
          ),
          6 => 
          array (
            'title' => 'Progress',
            'page' => 'features/bootstrap/progress',
          ),
          7 => 
          array (
            'title' => 'Modal',
            'page' => 'features/bootstrap/modal',
          ),
          8 => 
          array (
            'title' => 'Alerts',
            'page' => 'features/bootstrap/alerts',
          ),
          9 => 
          array (
            'title' => 'Popover',
            'page' => 'features/bootstrap/popover',
          ),
          10 => 
          array (
            'title' => 'Tooltip',
            'page' => 'features/bootstrap/tooltip',
          ),
        ),
      ),
      16 => 
      array (
        'title' => 'Custom',
        'icon' => 'media/svg/icons/Files/Pictures1.svg',
        'bullet' => 'dot',
        'root' => true,
        'submenu' => 
        array (
          0 => 
          array (
            'title' => 'Utilities',
            'page' => 'features/custom/utilities',
          ),
          1 => 
          array (
            'title' => 'Labels',
            'page' => 'features/custom/label',
          ),
          2 => 
          array (
            'title' => 'Line Tabs',
            'page' => 'features/custom/line-tabs',
          ),
          3 => 
          array (
            'title' => 'Advance Navs',
            'page' => 'features/custom/advance-navs',
          ),
          4 => 
          array (
            'title' => 'Timeline',
            'page' => 'features/custom/timeline',
          ),
          5 => 
          array (
            'title' => 'Pagination',
            'page' => 'features/custom/pagination',
          ),
          6 => 
          array (
            'title' => 'Symbol',
            'page' => 'features/custom/symbol',
          ),
          7 => 
          array (
            'title' => 'Overlay',
            'page' => 'features/custom/overlay',
          ),
          8 => 
          array (
            'title' => 'Spinners',
            'page' => 'features/custom/spinners',
          ),
          9 => 
          array (
            'title' => 'Iconbox',
            'page' => 'features/custom/iconbox',
          ),
          10 => 
          array (
            'title' => 'Callout',
            'page' => 'features/custom/callout',
          ),
          11 => 
          array (
            'title' => 'Ribbons',
            'page' => 'features/custom/ribbons',
          ),
          12 => 
          array (
            'title' => 'Accordions',
            'page' => 'features/custom/accordions',
          ),
        ),
      ),
      17 => 
      array (
        'title' => 'Cards',
        'icon' => 'media/svg/icons/Layout/Layout-arrange.svg',
        'bullet' => 'dot',
        'root' => true,
        'submenu' => 
        array (
          0 => 
          array (
            'title' => 'General Cards',
            'page' => 'features/cards/general',
          ),
          1 => 
          array (
            'title' => 'Stacked Cards',
            'page' => 'features/cards/stacked',
          ),
          2 => 
          array (
            'title' => 'Tabbed Cards',
            'page' => 'features/cards/tabbed',
          ),
          3 => 
          array (
            'title' => 'Draggable Cards',
            'page' => 'features/cards/draggable',
          ),
          4 => 
          array (
            'title' => 'Cards Tools',
            'page' => 'features/cards/tools',
          ),
          5 => 
          array (
            'title' => 'Sticky Cards',
            'page' => 'features/cards/sticky',
          ),
          6 => 
          array (
            'title' => 'Stretched Cards',
            'page' => 'features/cards/stretched',
          ),
        ),
      ),
      18 => 
      array (
        'title' => 'Widgets',
        'icon' => 'media/svg/icons/Devices/Diagnostics.svg',
        'root' => true,
        'bullet' => 'dot',
        'submenu' => 
        array (
          0 => 
          array (
            'title' => 'Lists',
            'page' => 'features/widgets/lists',
          ),
          1 => 
          array (
            'title' => 'Stats',
            'page' => 'features/widgets/stats',
          ),
          2 => 
          array (
            'title' => 'Charts',
            'page' => 'features/widgets/charts',
          ),
          3 => 
          array (
            'title' => 'Mixed',
            'page' => 'features/widgets/mixed',
          ),
          4 => 
          array (
            'title' => 'Tiles',
            'page' => 'features/widgets/tiles',
          ),
          5 => 
          array (
            'title' => 'Engage',
            'page' => 'features/widgets/engage',
          ),
          6 => 
          array (
            'title' => 'Base Tables',
            'page' => 'features/widgets/base-tables',
          ),
          7 => 
          array (
            'title' => 'Advance Tables',
            'page' => 'features/widgets/advance-tables',
          ),
          8 => 
          array (
            'title' => 'Forms',
            'page' => 'features/widgets/forms',
          ),
        ),
      ),
      19 => 
      array (
        'title' => 'Icons',
        'icon' => 'media/svg/icons/General/Attachment2.svg',
        'bullet' => 'dot',
        'submenu' => 
        array (
          0 => 
          array (
            'title' => 'SVG Icons',
            'page' => 'features/icons/svg',
          ),
          1 => 
          array (
            'title' => 'Flaticon',
            'page' => 'features/icons/flaticon',
          ),
          2 => 
          array (
            'title' => 'Fontawesome 5',
            'page' => 'features/icons/fontawesome5',
          ),
          3 => 
          array (
            'title' => 'Lineawesome',
            'page' => 'features/icons/lineawesome',
          ),
          4 => 
          array (
            'title' => 'Socicons',
            'page' => 'features/icons/socicons',
          ),
        ),
      ),
      20 => 
      array (
        'title' => 'Calendar',
        'icon' => 'media/svg/icons/Design/Select.svg',
        'bullet' => 'dot',
        'root' => true,
        'submenu' => 
        array (
          0 => 
          array (
            'title' => 'Basic Calendar',
            'page' => 'features/calendar/basic',
          ),
          1 => 
          array (
            'title' => 'List Views',
            'page' => 'features/calendar/list-view',
          ),
          2 => 
          array (
            'title' => 'Google Calendar',
            'page' => 'features/calendar/google',
          ),
          3 => 
          array (
            'title' => 'External Events',
            'page' => 'features/calendar/external-events',
          ),
          4 => 
          array (
            'title' => 'Background Events',
            'page' => 'features/calendar/background-events',
          ),
        ),
      ),
      21 => 
      array (
        'title' => 'Charts',
        'icon' => 'media/svg/icons/Media/Equalizer.svg',
        'root' => true,
        'bullet' => 'dot',
        'submenu' => 
        array (
          0 => 
          array (
            'title' => 'amCharts',
            'bullet' => 'dot',
            'submenu' => 
            array (
              0 => 
              array (
                'title' => 'amCharts Charts',
                'page' => 'features/charts/amcharts/charts',
              ),
              1 => 
              array (
                'title' => 'amCharts Stock Charts',
                'page' => 'features/charts/amcharts/stock-charts',
              ),
              2 => 
              array (
                'title' => 'amCharts Maps',
                'page' => 'features/charts/amcharts/maps',
              ),
            ),
          ),
          1 => 
          array (
            'title' => 'Flot Charts',
            'page' => 'features/charts/flotcharts',
          ),
          2 => 
          array (
            'title' => 'Google Charts',
            'page' => 'features/charts/google-charts',
          ),
          3 => 
          array (
            'title' => 'Morris Charts',
            'page' => 'features/charts/morris-charts',
          ),
        ),
      ),
      22 => 
      array (
        'title' => 'Maps',
        'icon' => 'media/svg/icons/Home/Book-open.svg',
        'root' => true,
        'bullet' => 'dot',
        'submenu' => 
        array (
          0 => 
          array (
            'title' => 'Google Maps',
            'page' => 'features/maps/google-maps',
          ),
          1 => 
          array (
            'title' => 'JQVMap',
            'page' => 'features/maps/jqvmap',
          ),
        ),
      ),
      23 => 
      array (
        'title' => 'Miscellaneous',
        'icon' => 'media/svg/icons/Home/Mirror.svg',
        'bullet' => 'dot',
        'root' => true,
        'submenu' => 
        array (
          0 => 
          array (
            'title' => 'Kanban Board',
            'page' => 'features/miscellaneous/kanban-board',
          ),
          1 => 
          array (
            'title' => 'Sticky Panels',
            'page' => 'features/miscellaneous/sticky-panels',
          ),
          2 => 
          array (
            'title' => 'Block UI',
            'page' => 'features/miscellaneous/blockui',
          ),
          3 => 
          array (
            'title' => 'Perfect Scrollbar',
            'page' => 'features/miscellaneous/perfect-scrollbar',
          ),
          4 => 
          array (
            'title' => 'Tree View',
            'page' => 'features/miscellaneous/treeview',
          ),
          5 => 
          array (
            'title' => 'Bootstrap Notify',
            'page' => 'features/miscellaneous/bootstrap-notify',
          ),
          6 => 
          array (
            'title' => 'Toastr',
            'page' => 'features/miscellaneous/toastr',
          ),
          7 => 
          array (
            'title' => 'SweetAlert2',
            'page' => 'features/miscellaneous/sweetalert2',
          ),
          8 => 
          array (
            'title' => 'Dual Listbox',
            'page' => 'features/miscellaneous/dual-listbox',
          ),
          9 => 
          array (
            'title' => 'Session Timeout',
            'page' => 'features/miscellaneous/session-timeout',
          ),
          10 => 
          array (
            'title' => 'Idle Timer',
            'page' => 'features/miscellaneous/idle-timer',
          ),
        ),
      ),
    ),
  ),
  'menu_header' => 
  array (
    'items' => 
    array (
      0 => 
      array (
      ),
      1 => 
      array (
        'title' => 'Dashboard',
        'root' => true,
        'page' => '/',
        'new-tab' => false,
      ),
      2 => 
      array (
        'title' => 'Features',
        'root' => true,
        'toggle' => 'click',
        'submenu' => 
        array (
          'type' => 'classic',
          'alignment' => 'left',
          'items' => 
          array (
            0 => 
            array (
              'title' => 'Bootstrap',
              'desc' => '',
              'icon' => 'media/svg/icons/Communication/Add-user.svg',
              'bullet' => 'dot',
              'submenu' => 
              array (
                0 => 
                array (
                  'title' => 'Utilities',
                  'page' => 'features/bootstrap/utilities',
                ),
                1 => 
                array (
                  'title' => 'Typography',
                  'page' => 'features/bootstrap/typography',
                ),
                2 => 
                array (
                  'title' => 'Buttons',
                  'page' => 'features/bootstrap/buttons',
                ),
                3 => 
                array (
                  'title' => 'Button Group',
                  'page' => 'features/bootstrap/button-group',
                ),
                4 => 
                array (
                  'title' => 'Dropdown',
                  'page' => 'features/bootstrap/dropdown',
                ),
                5 => 
                array (
                  'title' => 'Navs',
                  'page' => 'features/bootstrap/navs',
                ),
                6 => 
                array (
                  'title' => 'Tables',
                  'page' => 'features/bootstrap/tables',
                ),
                7 => 
                array (
                  'title' => 'Progress',
                  'page' => 'features/bootstrap/progress',
                ),
                8 => 
                array (
                  'title' => 'Modal',
                  'page' => 'features/bootstrap/modal',
                ),
                9 => 
                array (
                  'title' => 'Alerts',
                  'page' => 'features/bootstrap/alerts',
                ),
                10 => 
                array (
                  'title' => 'Popover',
                  'page' => 'features/bootstrap/popover',
                ),
                11 => 
                array (
                  'title' => 'Tooltip',
                  'page' => 'features/bootstrap/tooltip',
                ),
              ),
            ),
            1 => 
            array (
              'title' => 'Custom',
              'desc' => '',
              'icon' => 'media/svg/icons/Files/Pictures1.svg',
              'bullet' => 'dot',
              'submenu' => 
              array (
                0 => 
                array (
                  'title' => 'Utilities',
                  'page' => 'features/custom/utilities',
                ),
                1 => 
                array (
                  'title' => 'Accordions',
                  'page' => 'features/custom/accordions',
                ),
                2 => 
                array (
                  'title' => 'Label',
                  'page' => 'features/custom/labels',
                ),
                3 => 
                array (
                  'title' => 'Line Tabs',
                  'page' => 'features/custom/line-tabs',
                ),
                4 => 
                array (
                  'title' => 'Advance Navigations',
                  'page' => 'features/custom/advance-navs',
                ),
                5 => 
                array (
                  'title' => 'Timeline',
                  'page' => 'features/custom/timeline',
                ),
                6 => 
                array (
                  'title' => 'Pagination',
                  'page' => 'features/custom/pagination',
                ),
                7 => 
                array (
                  'title' => 'Media',
                  'page' => 'features/custom/media',
                ),
                8 => 
                array (
                  'title' => 'Spinners',
                  'page' => 'features/custom/spinners',
                ),
                9 => 
                array (
                  'title' => 'Iconbox',
                  'page' => 'features/custom/iconbox',
                ),
                10 => 
                array (
                  'title' => 'Callout',
                  'page' => 'features/custom/callout',
                ),
                11 => 
                array (
                  'title' => 'Ribbons',
                  'page' => 'features/custom/ribbons',
                ),
              ),
            ),
            2 => 
            array (
              'title' => 'Icons',
              'desc' => '',
              'icon' => 'media/svg/icons/Communication/Address-card.svg',
              'bullet' => 'dot',
              'submenu' => 
              array (
                0 => 
                array (
                  'title' => 'Flaticon',
                  'page' => 'features/icons/flaticon',
                ),
                1 => 
                array (
                  'title' => 'Fontawesome 5',
                  'page' => 'features/icons/fontawesome5',
                ),
                2 => 
                array (
                  'title' => 'Lineawesome',
                  'page' => 'features/icons/lineawesome',
                ),
                3 => 
                array (
                  'title' => 'Socicons',
                  'page' => 'features/icons/socicons',
                ),
                4 => 
                array (
                  'title' => 'SVG Icons',
                  'page' => 'features/svg/icons',
                ),
              ),
            ),
            3 => 
            array (
              'title' => 'Cards',
              'desc' => '',
              'icon' => 'media/svg/icons/Communication/Adress-book2.svg',
              'bullet' => 'dot',
              'submenu' => 
              array (
                0 => 
                array (
                  'title' => 'General Cards',
                  'page' => 'features/cards/general',
                ),
                1 => 
                array (
                  'title' => 'Stacked Cards',
                  'page' => 'features/cards/stacked',
                ),
                2 => 
                array (
                  'title' => 'Tabbed Cards',
                  'page' => 'features/cards/tabbed',
                ),
                3 => 
                array (
                  'title' => 'Draggable Cards',
                  'page' => 'features/cards/draggable',
                ),
                4 => 
                array (
                  'title' => 'Cards Tools',
                  'page' => 'features/cards/tools',
                ),
                5 => 
                array (
                  'title' => 'Sticky Cards',
                  'page' => 'features/cards/sticky',
                ),
                6 => 
                array (
                  'title' => 'Stretched Cards',
                  'page' => 'features/cards/stretched',
                ),
              ),
            ),
            4 => 
            array (
              'title' => 'Widgets',
              'desc' => 'dashboard widget examples',
              'icon' => 'media/svg/icons/Communication/Chat1.svg',
              'bullet' => 'dot',
              'submenu' => 
              array (
                0 => 
                array (
                  'title' => 'Lists',
                  'page' => 'features/widgets/lists',
                ),
                1 => 
                array (
                  'title' => 'Stats',
                  'page' => 'features/widgets/stats',
                ),
                2 => 
                array (
                  'title' => 'Charts',
                  'page' => 'features/widgets/charts',
                ),
                3 => 
                array (
                  'title' => 'Charts',
                  'page' => 'features/widgets/charts',
                ),
                4 => 
                array (
                  'title' => 'Mixed',
                  'page' => 'features/widgets/mixed',
                ),
                5 => 
                array (
                  'title' => 'Tiles',
                  'page' => 'features/widgets/tiles',
                ),
                6 => 
                array (
                  'title' => 'Engage',
                  'page' => 'features/widgets/engage',
                ),
                7 => 
                array (
                  'title' => 'Tables',
                  'page' => 'features/widgets/tables',
                ),
                8 => 
                array (
                  'title' => 'Forms',
                  'page' => 'features/widgets/forms',
                ),
              ),
            ),
            5 => 
            array (
              'title' => 'Calendar',
              'desc' => '',
              'icon' => 'media/svg/icons/Communication/Chat-check.svg',
              'bullet' => 'dot',
              'submenu' => 
              array (
                0 => 
                array (
                  'title' => 'Basic Calendar',
                  'page' => 'features/calendar/basic',
                ),
                1 => 
                array (
                  'title' => 'List Views',
                  'page' => 'features/calendar/list-view',
                ),
                2 => 
                array (
                  'title' => 'Google Calendar',
                  'page' => 'features/calendar/google',
                ),
                3 => 
                array (
                  'title' => 'External Events',
                  'page' => 'features/calendar/external-events',
                ),
                4 => 
                array (
                  'title' => 'Background Events',
                  'page' => 'features/calendar/background-events',
                ),
              ),
            ),
            6 => 
            array (
              'title' => 'Charts',
              'icon' => 'media/svg/icons/Communication/Dial-numbers.svg',
              'bullet' => 'dot',
              'submenu' => 
              array (
                0 => 
                array (
                  'title' => 'amCharts',
                  'bullet' => 'dot',
                  'submenu' => 
                  array (
                    0 => 
                    array (
                      'title' => 'amCharts Charts',
                      'page' => 'features/charts/amcharts/charts',
                    ),
                    1 => 
                    array (
                      'title' => 'amCharts Stock Charts',
                      'page' => 'features/charts/amcharts/stock-charts',
                    ),
                    2 => 
                    array (
                      'title' => 'amCharts Maps',
                      'page' => 'features/charts/amcharts/maps',
                    ),
                  ),
                ),
                1 => 
                array (
                  'title' => 'Flot Charts',
                  'page' => 'features/charts/flotcharts',
                ),
                2 => 
                array (
                  'title' => 'Google Charts',
                  'page' => 'features/charts/google-charts',
                ),
                3 => 
                array (
                  'title' => 'Morris Charts',
                  'page' => 'features/charts/morris-charts',
                ),
              ),
            ),
            7 => 
            array (
              'title' => 'Maps',
              'icon' => 'media/svg/icons/Communication/Incoming-box.svg',
              'bullet' => 'dot',
              'submenu' => 
              array (
                0 => 
                array (
                  'title' => 'Google Maps',
                  'page' => 'features/maps/google-maps',
                ),
                1 => 
                array (
                  'title' => 'JQVMap',
                  'page' => 'features/maps/jqvmap',
                ),
              ),
            ),
            8 => 
            array (
              'title' => 'Miscellaneous',
              'desc' => '',
              'icon' => 'media/svg/icons/Communication/Active-call.svg',
              'bullet' => 'dot',
              'submenu' => 
              array (
                0 => 
                array (
                  'title' => 'Kanban Board',
                  'page' => 'features/miscellaneous/kanban-board',
                ),
                1 => 
                array (
                  'title' => 'Sticky Panels',
                  'page' => 'features/miscellaneous/sticky-panels',
                ),
                2 => 
                array (
                  'title' => 'Block UI',
                  'page' => 'features/miscellaneous/blockui',
                ),
                3 => 
                array (
                  'title' => 'Perfect Scrollbar',
                  'page' => 'features/miscellaneous/perfect-scrollbar',
                ),
                4 => 
                array (
                  'title' => 'Tree View',
                  'page' => 'features/miscellaneous/treeview',
                ),
                5 => 
                array (
                  'title' => 'Bootstrap Notify',
                  'page' => 'features/miscellaneous/bootstrap-notify',
                ),
                6 => 
                array (
                  'title' => 'Toastr',
                  'page' => 'features/miscellaneous/toastr',
                ),
                7 => 
                array (
                  'title' => 'SweetAlert2',
                  'page' => 'features/miscellaneous/sweetalert2',
                ),
                8 => 
                array (
                  'title' => 'Dual Listbox',
                  'page' => 'features/miscellaneous/dual-listbox',
                ),
                9 => 
                array (
                  'title' => 'Session Timeout',
                  'page' => 'features/miscellaneous/session-timeout',
                ),
                10 => 
                array (
                  'title' => 'Idle Timer',
                  'page' => 'features/miscellaneous/idle-timer',
                ),
              ),
            ),
          ),
        ),
      ),
      3 => 
      array (
        'title' => 'Crud',
        'root' => true,
        'toggle' => 'click',
        'submenu' => 
        array (
          'type' => 'classic',
          'alignment' => 'left',
          'items' => 
          array (
            0 => 
            array (
              'title' => 'Forms & Controls',
              'desc' => 'Massive crud examples',
              'icon' => 'media/svg/icons/Shopping/Box2.svg',
              'bullet' => 'dot',
              'submenu' => 
              array (
                0 => 
                array (
                  'title' => 'Form Controls',
                  'desc' => '',
                  'icon' => 'flaticon-interface-3',
                  'bullet' => 'dot',
                  'submenu' => 
                  array (
                    0 => 
                    array (
                      'title' => 'Base Inputs',
                      'page' => 'crud/forms/controls/base',
                    ),
                    1 => 
                    array (
                      'title' => 'Input Groups',
                      'page' => 'crud/forms/controls/input-group',
                    ),
                    2 => 
                    array (
                      'title' => 'Checkbox',
                      'page' => 'crud/forms/controls/checkbox',
                    ),
                    3 => 
                    array (
                      'title' => 'Radio',
                      'page' => 'crud/forms/controls/radio',
                    ),
                    4 => 
                    array (
                      'title' => 'Switch',
                      'page' => 'crud/forms/controls/switch',
                    ),
                    5 => 
                    array (
                      'title' => 'Mega Options',
                      'page' => 'crud/forms/controls/option',
                    ),
                  ),
                ),
                1 => 
                array (
                  'title' => 'Form Widgets',
                  'desc' => '',
                  'icon' => 'flaticon-interface-1',
                  'bullet' => 'dot',
                  'submenu' => 
                  array (
                    0 => 
                    array (
                      'title' => 'Datepicker',
                      'page' => 'crud/forms/widgets/bootstrap-datepicker',
                    ),
                    1 => 
                    array (
                      'title' => 'Datetimepicker',
                      'page' => 'crud/forms/widgets/bootstrap-datetimepicker',
                    ),
                    2 => 
                    array (
                      'title' => 'Timepicker',
                      'page' => 'crud/forms/widgets/bootstrap-timepicker',
                    ),
                    3 => 
                    array (
                      'title' => 'Daterangepicker',
                      'page' => 'crud/forms/widgets/bootstrap-daterangepicker',
                    ),
                    4 => 
                    array (
                      'title' => 'Tagify',
                      'page' => 'crud/forms/widgets/tagify',
                    ),
                    5 => 
                    array (
                      'title' => 'Touchspin',
                      'page' => 'crud/forms/widgets/bootstrap-touchspin',
                    ),
                    6 => 
                    array (
                      'title' => 'Maxlength',
                      'page' => 'crud/forms/widgets/bootstrap-maxlength',
                    ),
                    7 => 
                    array (
                      'title' => 'Switch',
                      'page' => 'crud/forms/widgets/bootstrap-switch',
                    ),
                    8 => 
                    array (
                      'title' => 'Multiple Select Splitter',
                      'page' => 'crud/forms/widgets/bootstrap-multipleselectsplitter',
                    ),
                    9 => 
                    array (
                      'title' => 'Bootstrap Select',
                      'page' => 'crud/forms/widgets/bootstrap-select',
                    ),
                    10 => 
                    array (
                      'title' => 'Select2',
                      'page' => 'crud/forms/widgets/select2',
                    ),
                    11 => 
                    array (
                      'title' => 'Typeahead',
                      'page' => 'crud/forms/widgets/typeahead',
                    ),
                  ),
                ),
                2 => 
                array (
                  'title' => 'Form Widgets 2',
                  'desc' => '',
                  'icon' => 'flaticon-interface-1',
                  'bullet' => 'dot',
                  'submenu' => 
                  array (
                    0 => 
                    array (
                      'title' => 'noUiSlider',
                      'page' => 'crud/forms/widgets/nouislider',
                    ),
                    1 => 
                    array (
                      'title' => 'Form Repeater',
                      'page' => 'crud/forms/widgets/form-repeater',
                    ),
                    2 => 
                    array (
                      'title' => 'Ion Range Slider',
                      'page' => 'crud/forms/widgets/ion-range-slider',
                    ),
                    3 => 
                    array (
                      'title' => 'Input Masks',
                      'page' => 'crud/forms/widgets/input-mask',
                    ),
                    4 => 
                    array (
                      'title' => 'Autosize',
                      'page' => 'crud/forms/widgets/autosize',
                    ),
                    5 => 
                    array (
                      'title' => 'Clipboard',
                      'page' => 'crud/forms/widgets/clipboard',
                    ),
                    6 => 
                    array (
                      'title' => 'Google reCaptcha',
                      'page' => 'crud/forms/widgets/recaptcha',
                    ),
                  ),
                ),
                3 => 
                array (
                  'title' => 'Form Text Editors',
                  'desc' => '',
                  'icon' => 'flaticon-interface-1',
                  'bullet' => 'dot',
                  'submenu' => 
                  array (
                    0 => 
                    array (
                      'title' => 'TinyMCE',
                      'page' => 'crud/forms/editors/tinymce',
                    ),
                    1 => 
                    array (
                      'title' => 'CKEditor',
                      'bullet' => 'line',
                      'submenu' => 
                      array (
                        0 => 
                        array (
                          'title' => 'CKEditor Classic',
                          'page' => 'crud/forms/editors/ckeditor-classic',
                        ),
                        1 => 
                        array (
                          'title' => 'CKEditor Inline',
                          'page' => 'crud/forms/editors/ckeditor-inline',
                        ),
                        2 => 
                        array (
                          'title' => 'CKEditor Balloon',
                          'page' => 'crud/forms/editors/ckeditor-balloon',
                        ),
                        3 => 
                        array (
                          'title' => 'CKEditor Balloon Block',
                          'page' => 'crud/forms/editors/ckeditor-balloon-block',
                        ),
                        4 => 
                        array (
                          'title' => 'CKEditor Document',
                          'page' => 'crud/forms/editors/ckeditor-document',
                        ),
                      ),
                    ),
                    2 => 
                    array (
                      'title' => 'Quill Text Editor',
                      'page' => 'crud/forms/editors/quill',
                    ),
                    3 => 
                    array (
                      'title' => 'Summernote WYSIWYG',
                      'page' => 'crud/forms/editors/summernote',
                    ),
                    4 => 
                    array (
                      'title' => 'Markdown Editor',
                      'page' => 'crud/forms/editors/bootstrap-markdown',
                    ),
                  ),
                ),
                4 => 
                array (
                  'title' => 'Form Layouts',
                  'desc' => '',
                  'icon' => 'flaticon-web',
                  'bullet' => 'dot',
                  'submenu' => 
                  array (
                    0 => 
                    array (
                      'title' => 'Default Forms',
                      'page' => 'crud/forms/layouts/default-forms',
                    ),
                    1 => 
                    array (
                      'title' => 'Multi Column Forms',
                      'page' => 'crud/forms/layouts/multi-column-forms',
                    ),
                    2 => 
                    array (
                      'title' => 'Basic Action Bars',
                      'page' => 'crud/forms/layouts/action-bars',
                    ),
                    3 => 
                    array (
                      'title' => 'Sticky Action Bar',
                      'page' => 'crud/forms/layouts/sticky-action-bar',
                    ),
                  ),
                ),
                5 => 
                array (
                  'title' => 'Form Validation',
                  'desc' => '',
                  'icon' => 'flaticon-calendar-2',
                  'bullet' => 'dot',
                  'submenu' => 
                  array (
                    0 => 
                    array (
                      'title' => 'Validation States',
                      'page' => 'crud/forms/validation/states',
                    ),
                    1 => 
                    array (
                      'title' => 'Form Controls',
                      'page' => 'crud/forms/validation/form-controls',
                    ),
                    2 => 
                    array (
                      'title' => 'Form Widgets',
                      'page' => 'crud/forms/validation/form-widgets',
                    ),
                  ),
                ),
              ),
            ),
            1 => 
            array (
              'title' => 'KTDatatable',
              'desc' => '',
              'icon' => 'media/svg/icons/General/Thunder-move.svg',
              'bullet' => 'dot',
              'submenu' => 
              array (
                0 => 
                array (
                  'title' => 'Base',
                  'desc' => '',
                  'bullet' => 'dot',
                  'submenu' => 
                  array (
                    0 => 
                    array (
                      'title' => 'Local Data',
                      'page' => 'crud/ktdatatable/base/data-local',
                      'icon' => '',
                    ),
                    1 => 
                    array (
                      'title' => 'JSON Data',
                      'page' => 'crud/ktdatatable/base/data-json',
                      'icon' => '',
                    ),
                    2 => 
                    array (
                      'title' => 'Ajax Data',
                      'page' => 'crud/ktdatatable/base/data-ajax',
                      'icon' => '',
                    ),
                    3 => 
                    array (
                      'title' => 'HTML Table',
                      'page' => 'crud/ktdatatable/base/html-table',
                      'icon' => '',
                    ),
                    4 => 
                    array (
                      'title' => 'Local Sort',
                      'page' => 'crud/ktdatatable/base/local-sort',
                      'icon' => '',
                    ),
                    5 => 
                    array (
                      'title' => 'Translation',
                      'page' => 'crud/ktdatatable/base/translation',
                      'icon' => '',
                    ),
                  ),
                ),
                1 => 
                array (
                  'title' => 'Advanced',
                  'desc' => '',
                  'bullet' => 'dot',
                  'submenu' => 
                  array (
                    0 => 
                    array (
                      'title' => 'Record Selection',
                      'page' => 'crud/ktdatatable/advanced/record-selection',
                      'icon' => '',
                    ),
                    1 => 
                    array (
                      'title' => 'Row Details',
                      'page' => 'crud/ktdatatable/advanced/row-details',
                      'icon' => '',
                    ),
                    2 => 
                    array (
                      'title' => 'Modal Examples',
                      'page' => 'crud/ktdatatable/advanced/modal',
                      'icon' => '',
                    ),
                    3 => 
                    array (
                      'title' => 'Column Rendering',
                      'page' => 'crud/ktdatatable/advanced/column-rendering',
                      'icon' => '',
                    ),
                    4 => 
                    array (
                      'title' => 'Column Width',
                      'page' => 'crud/ktdatatable/advanced/column-width',
                      'icon' => '',
                    ),
                    5 => 
                    array (
                      'title' => 'Vertical Scrolling',
                      'page' => 'crud/ktdatatable/advanced/vertical',
                      'icon' => '',
                    ),
                  ),
                ),
                2 => 
                array (
                  'title' => 'Child Datatables',
                  'desc' => '',
                  'bullet' => 'dot',
                  'submenu' => 
                  array (
                    0 => 
                    array (
                      'title' => 'Local Data',
                      'page' => 'crud/ktdatatable/child/data-local',
                      'icon' => '',
                    ),
                    1 => 
                    array (
                      'title' => 'Remote Data',
                      'page' => 'crud/ktdatatable/child/data-ajax',
                      'icon' => '',
                    ),
                  ),
                ),
                3 => 
                array (
                  'title' => 'API',
                  'desc' => '',
                  'bullet' => 'dot',
                  'submenu' => 
                  array (
                    0 => 
                    array (
                      'title' => 'API Methods',
                      'page' => 'crud/ktdatatable/api/methods',
                      'icon' => '',
                    ),
                    1 => 
                    array (
                      'title' => 'Events',
                      'page' => 'crud/ktdatatable/api/events',
                      'icon' => '',
                    ),
                  ),
                ),
              ),
            ),
            2 => 
            array (
              'title' => 'Datatables.net',
              'desc' => '',
              'icon' => 'media/svg/icons/Shopping/Gift.svg',
              'bullet' => 'dot',
              'submenu' => 
              array (
                0 => 
                array (
                  'title' => 'Basic',
                  'desc' => '',
                  'bullet' => 'dot',
                  'submenu' => 
                  array (
                    0 => 
                    array (
                      'title' => 'Basic Tables',
                      'page' => 'crud/datatables/basic/basic',
                    ),
                    1 => 
                    array (
                      'title' => 'Scrollable Tables',
                      'page' => 'crud/datatables/basic/scrollable',
                    ),
                    2 => 
                    array (
                      'title' => 'Complex Headers',
                      'page' => 'crud/datatables/basic/headers',
                    ),
                    3 => 
                    array (
                      'title' => 'Pagination Options',
                      'page' => 'crud/datatables/basic/paginations',
                    ),
                  ),
                ),
                1 => 
                array (
                  'title' => 'Advanced',
                  'desc' => '',
                  'bullet' => 'dot',
                  'submenu' => 
                  array (
                    0 => 
                    array (
                      'title' => 'Column Rendering',
                      'page' => 'crud/datatables/advanced/column-rendering',
                    ),
                    1 => 
                    array (
                      'title' => 'Multiple Controls',
                      'page' => 'crud/datatables/advanced/multiple-controls',
                    ),
                    2 => 
                    array (
                      'title' => 'Column Visibility',
                      'page' => 'crud/datatables/advanced/column-visibility',
                    ),
                    3 => 
                    array (
                      'title' => 'Row Callback',
                      'page' => 'crud/datatables/advanced/row-callback',
                    ),
                    4 => 
                    array (
                      'title' => 'Row Grouping',
                      'page' => 'crud/datatables/advanced/row-grouping',
                    ),
                    5 => 
                    array (
                      'title' => 'Footer Callback',
                      'page' => 'crud/datatables/advanced/footer-callback',
                    ),
                  ),
                ),
                2 => 
                array (
                  'title' => 'Data sources',
                  'desc' => '',
                  'bullet' => 'dot',
                  'submenu' => 
                  array (
                    0 => 
                    array (
                      'title' => 'HTML',
                      'page' => 'crud/datatables/data-sources/html',
                    ),
                    1 => 
                    array (
                      'title' => 'Javascript',
                      'page' => 'crud/datatables/data-sources/javascript',
                    ),
                    2 => 
                    array (
                      'title' => 'Ajax Client-side',
                      'page' => 'crud/datatables/data-sources/ajax-client-side',
                    ),
                    3 => 
                    array (
                      'title' => 'Ajax Server-side',
                      'page' => 'crud/datatables/data-sources/ajax-server-side',
                    ),
                  ),
                ),
                3 => 
                array (
                  'title' => 'Search Options',
                  'desc' => '',
                  'bullet' => 'dot',
                  'submenu' => 
                  array (
                    0 => 
                    array (
                      'title' => 'Column Search',
                      'page' => 'crud/datatables/search-options/column-search',
                    ),
                    1 => 
                    array (
                      'title' => 'Advanced Search',
                      'page' => 'crud/datatables/search-options/advanced-search',
                    ),
                  ),
                ),
                4 => 
                array (
                  'title' => 'Extensions',
                  'desc' => '',
                  'bullet' => 'dot',
                  'submenu' => 
                  array (
                    0 => 
                    array (
                      'title' => 'Buttons',
                      'page' => 'crud/datatables/extensions/buttons',
                    ),
                    1 => 
                    array (
                      'title' => 'ColReorder',
                      'page' => 'crud/datatables/extensions/colreorder',
                    ),
                    2 => 
                    array (
                      'title' => 'KeyTable',
                      'page' => 'crud/datatables/extensions/keytable',
                    ),
                    3 => 
                    array (
                      'title' => 'Responsive',
                      'page' => 'crud/datatables/extensions/responsive',
                    ),
                    4 => 
                    array (
                      'title' => 'RowGroup',
                      'page' => 'crud/datatables/extensions/rowgroup',
                    ),
                    5 => 
                    array (
                      'title' => 'RowReorder',
                      'page' => 'crud/datatables/extensions/rowreorder',
                    ),
                    6 => 
                    array (
                      'title' => 'Scroller',
                      'page' => 'crud/datatables/extensions/scroller',
                    ),
                    7 => 
                    array (
                      'title' => 'Select',
                      'page' => 'crud/datatables/extensions/select',
                    ),
                  ),
                ),
              ),
            ),
            3 => 
            array (
              'title' => 'File Upload',
              'desc' => '',
              'icon' => 'media/svg/icons/Shopping/Gift.svg',
              'bullet' => 'dot',
              'submenu' => 
              array (
                0 => 
                array (
                  'title' => 'Image Input',
                  'page' => 'crud/file-upload/image-input',
                ),
                1 => 
                array (
                  'title' => 'DropzoneJS',
                  'page' => 'crud/file-upload/dropzonejs',
                ),
                2 => 
                array (
                  'title' => 'Uppy',
                  'page' => 'crud/file-upload/uppy',
                ),
              ),
            ),
          ),
        ),
      ),
      4 => 
      array (
        'title' => 'Apps',
        'root' => true,
        'toggle' => 'click',
        'submenu' => 
        array (
          'type' => 'classic',
          'alignment' => 'left',
          'items' => 
          array (
            0 => 
            array (
              'title' => 'Users',
              'bullet' => 'dot',
              'icon' => 'media/svg/icons/Communication/Address-card.svg',
              'submenu' => 
              array (
                0 => 
                array (
                  'title' => 'List - Default',
                  'page' => 'custom/apps/user/list-default',
                ),
                1 => 
                array (
                  'title' => 'List - Datatable',
                  'page' => 'custom/apps/user/list-datatable',
                ),
                2 => 
                array (
                  'title' => 'List - Columns 1',
                  'page' => 'custom/apps/user/list-columns-1',
                ),
                3 => 
                array (
                  'title' => 'List - Columns 2',
                  'page' => 'custom/apps/user/list-columns-2',
                ),
                4 => 
                array (
                  'title' => 'Add User',
                  'page' => 'custom/apps/user/add-user',
                ),
                5 => 
                array (
                  'title' => 'Edit User',
                  'page' => 'custom/apps/user/edit-user',
                ),
              ),
            ),
            1 => 
            array (
              'title' => 'Profile',
              'bullet' => 'dot',
              'icon' => 'media/svg/icons/Communication/Address-card.svg',
              'submenu' => 
              array (
                0 => 
                array (
                  'title' => 'Profile 1',
                  'bullet' => 'line',
                  'submenu' => 
                  array (
                    0 => 
                    array (
                      'title' => 'Overview',
                      'page' => 'custom/apps/profile/profile-1/overview',
                    ),
                    1 => 
                    array (
                      'title' => 'Personal Information',
                      'page' => 'custom/apps/profile/profile-1/personal-information',
                    ),
                    2 => 
                    array (
                      'title' => 'Account Information',
                      'page' => 'custom/apps/profile/profile-1/account-information',
                    ),
                    3 => 
                    array (
                      'title' => 'Change Password',
                      'page' => 'custom/apps/profile/profile-1/change-password',
                    ),
                    4 => 
                    array (
                      'title' => 'Email Settings',
                      'page' => 'custom/apps/profile/profile-1/email-settings',
                    ),
                  ),
                ),
                1 => 
                array (
                  'title' => 'Profile 2',
                  'page' => 'custom/apps/profile/profile-2',
                ),
                2 => 
                array (
                  'title' => 'Profile 3',
                  'page' => 'custom/apps/profile/profile-3',
                ),
                3 => 
                array (
                  'title' => 'Profile 4',
                  'page' => 'custom/apps/profile/profile-4',
                ),
              ),
            ),
            2 => 
            array (
              'title' => 'Contacts',
              'bullet' => 'dot',
              'icon' => 'media/svg/icons/Communication/Adress-book1.svg',
              'submenu' => 
              array (
                0 => 
                array (
                  'title' => 'List - Columns',
                  'page' => 'custom/apps/contacts/list-columns',
                ),
                1 => 
                array (
                  'title' => 'List - Datatable',
                  'page' => 'custom/apps/contacts/list-datatable',
                ),
                2 => 
                array (
                  'title' => 'View Contact',
                  'page' => 'custom/apps/contacts/view-contact',
                ),
                3 => 
                array (
                  'title' => 'Add Contact',
                  'page' => 'custom/apps/contacts/add-contact',
                ),
                4 => 
                array (
                  'title' => 'Edit Contact',
                  'page' => 'custom/apps/contacts/edit-cotact',
                ),
              ),
            ),
            3 => 
            array (
              'title' => 'Chat',
              'bullet' => 'dot',
              'icon' => 'media/svg/icons/Communication/Mail-opened.svg',
              'submenu' => 
              array (
                0 => 
                array (
                  'title' => 'Private',
                  'page' => 'custom/apps/chat/private',
                ),
                1 => 
                array (
                  'title' => 'Group',
                  'page' => 'custom/apps/chat/group',
                ),
                2 => 
                array (
                  'title' => 'Popup',
                  'page' => 'custom/apps/chat/popup',
                ),
              ),
            ),
            4 => 
            array (
              'title' => 'Projects',
              'bullet' => 'dot',
              'icon' => 'media/svg/icons/Shopping/Box2.svg',
              'submenu' => 
              array (
                0 => 
                array (
                  'title' => 'List - Columns 1',
                  'page' => 'custom/apps/projects/list-columns-1',
                ),
                1 => 
                array (
                  'title' => 'List - Columns 2',
                  'page' => 'custom/apps/projects/list-columns-2',
                ),
                2 => 
                array (
                  'title' => 'List - Columns 3',
                  'page' => 'custom/apps/projects/list-columns-3',
                ),
                3 => 
                array (
                  'title' => 'List - Columns 4',
                  'page' => 'custom/apps/projects/list-columns-4',
                ),
                4 => 
                array (
                  'title' => 'List - Datatable',
                  'page' => 'custom/apps/projects/list-datatable',
                ),
                5 => 
                array (
                  'title' => 'View Project',
                  'page' => 'custom/apps/projects/view-project',
                ),
                6 => 
                array (
                  'title' => 'Add Project',
                  'page' => 'custom/apps/projects/add-project',
                ),
                7 => 
                array (
                  'title' => 'Edit Project',
                  'page' => 'custom/apps/projects/edit-project',
                ),
              ),
            ),
            5 => 
            array (
              'title' => 'Support Center',
              'bullet' => 'dot',
              'icon' => 'media/svg/icons/General/Shield-check.svg',
              'submenu' => 
              array (
                0 => 
                array (
                  'title' => 'Home 1',
                  'page' => 'custom/apps/support-center/home-1',
                ),
                1 => 
                array (
                  'title' => 'Home 2',
                  'page' => 'custom/apps/support-center/home-2',
                ),
                2 => 
                array (
                  'title' => 'FAQ 1',
                  'page' => 'custom/apps/support-center/faq-1',
                ),
                3 => 
                array (
                  'title' => 'FAQ 2',
                  'page' => 'custom/apps/support-center/faq-2',
                ),
                4 => 
                array (
                  'title' => 'FAQ 3',
                  'page' => 'custom/apps/support-center/faq-3',
                ),
                5 => 
                array (
                  'title' => 'Feedback',
                  'page' => 'custom/apps/support-center/feedback',
                ),
                6 => 
                array (
                  'title' => 'License',
                  'page' => 'custom/apps/support-center/license',
                ),
              ),
            ),
            6 => 
            array (
              'title' => 'Todo',
              'bullet' => 'dot',
              'icon' => 'media/svg/icons/Communication/Clipboard-list.svg',
              'submenu' => 
              array (
                0 => 
                array (
                  'title' => 'Tasks',
                  'page' => 'custom/apps/todo/tasks',
                ),
                1 => 
                array (
                  'title' => 'Docs',
                  'page' => 'custom/apps/todo/docs',
                ),
                2 => 
                array (
                  'title' => 'Files',
                  'page' => 'custom/apps/todo/files',
                ),
              ),
            ),
            7 => 
            array (
              'title' => 'Inbox',
              'bullet' => 'dot',
              'label' => 
              array (
                'type' => 'label-danger label-inline',
                'value' => 'new',
              ),
              'icon' => 'media/svg/icons/General/Shield-check.svg',
              'page' => 'custom/apps/inbox',
            ),
          ),
        ),
      ),
      5 => 
      array (
        'title' => 'Pages',
        'root' => true,
        'toggle' => 'click',
        'submenu' => 
        array (
          'type' => 'mega',
          'width' => '1000px',
          'alignment' => 'center',
          'columns' => 
          array (
            0 => 
            array (
              'bullet' => 'line',
              'heading' => 
              array (
                'heading' => true,
                'title' => 'Pricing Tables',
                'desc' => '',
              ),
              'items' => 
              array (
                0 => 
                array (
                  'title' => 'Pricing Tables 1',
                  'page' => 'custom/pages/pricing/pricing-1',
                ),
                1 => 
                array (
                  'title' => 'Pricing Tables 2',
                  'page' => 'custom/pages/pricing/pricing-2',
                ),
                2 => 
                array (
                  'title' => 'Pricing Tables 3',
                  'page' => 'custom/pages/pricing/pricing-3',
                ),
                3 => 
                array (
                  'title' => 'Pricing Tables 4',
                  'page' => 'custom/pages/pricing/pricing-4',
                ),
              ),
            ),
            1 => 
            array (
              'bullet' => 'line',
              'heading' => 
              array (
                'heading' => true,
                'title' => 'Wizards',
                'desc' => '',
              ),
              'items' => 
              array (
                0 => 
                array (
                  'title' => 'Wizard 1',
                  'page' => 'custom/pages/wizard/wizard-1',
                ),
                1 => 
                array (
                  'title' => 'Wizard 2',
                  'page' => 'custom/pages/wizard/wizard-2',
                ),
                2 => 
                array (
                  'title' => 'Wizard 3',
                  'page' => 'custom/pages/wizard/wizard-3',
                ),
                3 => 
                array (
                  'title' => 'Wizard 4',
                  'page' => 'custom/pages/wizard/wizard-4',
                ),
              ),
            ),
            2 => 
            array (
              'bullet' => 'line',
              'heading' => 
              array (
                'heading' => true,
                'title' => 'Invoices & FAQ',
                'desc' => '',
                'bullet' => 'dot',
              ),
              'items' => 
              array (
                0 => 
                array (
                  'title' => 'Invoice 1',
                  'page' => 'custom/pages/invoices/invoice-1',
                ),
                1 => 
                array (
                  'title' => 'Invoice 2',
                  'page' => 'custom/pages/invoices/invoice-2',
                ),
                2 => 
                array (
                  'title' => 'FAQ 1',
                  'page' => 'custom/pages/faq/faq-1',
                ),
              ),
            ),
            3 => 
            array (
              'bullet' => 'line',
              'heading' => 
              array (
                'heading' => true,
                'title' => 'User Pages',
                'bullet' => 'dot',
              ),
              'items' => 
              array (
                0 => 
                array (
                  'title' => 'Login 1',
                  'page' => 'custom/pages/user/login-1',
                  'new-tab' => true,
                ),
                1 => 
                array (
                  'title' => 'Login 2',
                  'page' => 'custom/pages/user/login-2',
                  'new-tab' => true,
                ),
                2 => 
                array (
                  'title' => 'Login 3',
                  'page' => 'custom/pages/user/login-3',
                  'new-tab' => true,
                ),
                3 => 
                array (
                  'title' => 'Login 4',
                  'page' => 'custom/pages/user/login-4',
                  'new-tab' => true,
                ),
                4 => 
                array (
                  'title' => 'Login 5',
                  'page' => 'custom/pages/user/login-5',
                  'new-tab' => true,
                ),
                5 => 
                array (
                  'title' => 'Login 6',
                  'page' => 'custom/pages/user/login-6',
                  'new-tab' => true,
                ),
              ),
            ),
            4 => 
            array (
              'bullet' => 'line',
              'heading' => 
              array (
                'heading' => true,
                'title' => 'Error Pages',
                'bullet' => 'dot',
              ),
              'items' => 
              array (
                0 => 
                array (
                  'title' => 'Error 1',
                  'page' => 'custom/pages/errors/error-1',
                  'new-tab' => true,
                ),
                1 => 
                array (
                  'title' => 'Error 2',
                  'page' => 'custom/pages/errors/error-2',
                  'new-tab' => true,
                ),
                2 => 
                array (
                  'title' => 'Error 3',
                  'page' => 'custom/pages/errors/error-3',
                  'new-tab' => true,
                ),
                3 => 
                array (
                  'title' => 'Error 4',
                  'page' => 'custom/pages/errors/error-4',
                  'new-tab' => true,
                ),
                4 => 
                array (
                  'title' => 'Error 5',
                  'page' => 'custom/pages/errors/error-5',
                  'new-tab' => true,
                ),
                5 => 
                array (
                  'title' => 'Error 6',
                  'page' => 'custom/pages/errors/error-6',
                  'new-tab' => true,
                ),
              ),
            ),
          ),
        ),
      ),
    ),
  ),
  'permission' => 
  array (
    'models' => 
    array (
      'permission' => 'Spatie\\Permission\\Models\\Permission',
      'role' => 'Spatie\\Permission\\Models\\Role',
    ),
    'table_names' => 
    array (
      'roles' => 'roles',
      'permissions' => 'permissions',
      'model_has_permissions' => 'model_has_permissions',
      'model_has_roles' => 'model_has_roles',
      'role_has_permissions' => 'role_has_permissions',
    ),
    'column_names' => 
    array (
      'role_pivot_key' => NULL,
      'permission_pivot_key' => NULL,
      'model_morph_key' => 'model_id',
      'team_foreign_key' => 'team_id',
    ),
    'register_permission_check_method' => true,
    'teams' => false,
    'display_permission_in_exception' => false,
    'display_role_in_exception' => false,
    'enable_wildcard_permission' => false,
    'cache' => 
    array (
      'expiration_time' => 
      DateInterval::__set_state(array(
         'y' => 0,
         'm' => 0,
         'd' => 0,
         'h' => 24,
         'i' => 0,
         's' => 0,
         'f' => 0.0,
         'weekday' => 0,
         'weekday_behavior' => 0,
         'first_last_day_of' => 0,
         'invert' => 0,
         'days' => false,
         'special_type' => 0,
         'special_amount' => 0,
         'have_weekday_relative' => 0,
         'have_special_relative' => 0,
      )),
      'key' => 'spatie.permission.cache',
      'store' => 'default',
    ),
  ),
  'queue' => 
  array (
    'default' => 'sync',
    'connections' => 
    array (
      'sync' => 
      array (
        'driver' => 'sync',
      ),
      'database' => 
      array (
        'driver' => 'database',
        'table' => 'jobs',
        'queue' => 'default',
        'retry_after' => 90,
      ),
      'beanstalkd' => 
      array (
        'driver' => 'beanstalkd',
        'host' => 'localhost',
        'queue' => 'default',
        'retry_after' => 90,
        'block_for' => 0,
      ),
      'sqs' => 
      array (
        'driver' => 'sqs',
        'key' => '',
        'secret' => '',
        'prefix' => 'https://sqs.us-east-1.amazonaws.com/your-account-id',
        'queue' => 'your-queue-name',
        'region' => 'us-east-1',
      ),
      'redis' => 
      array (
        'driver' => 'redis',
        'connection' => 'default',
        'queue' => 'default',
        'retry_after' => 90,
        'block_for' => NULL,
      ),
    ),
    'failed' => 
    array (
      'driver' => 'database',
      'database' => 'mysql',
      'table' => 'failed_jobs',
    ),
  ),
  'services' => 
  array (
    'mailgun' => 
    array (
      'domain' => NULL,
      'secret' => NULL,
      'endpoint' => 'api.mailgun.net',
    ),
    'postmark' => 
    array (
      'token' => NULL,
    ),
    'ses' => 
    array (
      'key' => '',
      'secret' => '',
      'region' => 'us-east-1',
    ),
    'github' => 
    array (
      'client_id' => 'cf260d629e0626fea877',
      'client_secret' => 'ad98d9ba0cdd0228b4681e94e037cc474a915752',
      'redirect' => 'GITHUB_REDIRECT_URI',
    ),
    'facebook' => 
    array (
      'client_id' => NULL,
      'client_secret' => NULL,
      'redirect' => NULL,
    ),
    'google' => 
    array (
      'client_id' => NULL,
      'client_secret' => NULL,
      'redirect' => NULL,
    ),
    'linkedin' => 
    array (
      'client_id' => NULL,
      'client_secret' => NULL,
      'redirect' => NULL,
    ),
    'twitter' => 
    array (
      'client_id' => '',
      'client_secret' => '',
      'redirect' => NULL,
    ),
  ),
  'session' => 
  array (
    'driver' => 'file',
    'lifetime' => '120',
    'expire_on_close' => false,
    'encrypt' => false,
    'files' => 'C:\\wamp64\\www\\omar\\storage\\framework/sessions',
    'connection' => NULL,
    'table' => 'sessions',
    'store' => NULL,
    'lottery' => 
    array (
      0 => 2,
      1 => 100,
    ),
    'cookie' => 'omar_session',
    'path' => '/',
    'domain' => NULL,
    'secure' => NULL,
    'http_only' => true,
    'same_site' => 'lax',
  ),
  'view' => 
  array (
    'paths' => 
    array (
      0 => 'C:\\wamp64\\www\\omar\\resources\\views',
    ),
    'compiled' => 'C:\\wamp64\\www\\omar\\storage\\framework\\views',
    'expires' => true,
  ),
  'flare' => 
  array (
    'key' => NULL,
    'reporting' => 
    array (
      'anonymize_ips' => true,
      'collect_git_information' => false,
      'report_queries' => true,
      'maximum_number_of_collected_queries' => 200,
      'report_query_bindings' => true,
      'report_view_data' => true,
      'grouping_type' => NULL,
      'report_logs' => true,
      'maximum_number_of_collected_logs' => 200,
      'censor_request_body_fields' => 
      array (
        0 => 'password',
      ),
    ),
    'send_logs_as_events' => true,
    'censor_request_body_fields' => 
    array (
      0 => 'password',
    ),
  ),
  'ignition' => 
  array (
    'editor' => 'phpstorm',
    'theme' => 'light',
    'enable_share_button' => true,
    'register_commands' => false,
    'ignored_solution_providers' => 
    array (
      0 => 'Facade\\Ignition\\SolutionProviders\\MissingPackageSolutionProvider',
    ),
    'enable_runnable_solutions' => NULL,
    'remote_sites_path' => '',
    'local_sites_path' => '',
    'housekeeping_endpoint_prefix' => '_ignition',
  ),
  'passport' => 
  array (
    'private_key' => NULL,
    'public_key' => NULL,
    'client_uuids' => false,
    'personal_access_client' => 
    array (
      'id' => NULL,
      'secret' => NULL,
    ),
    'storage' => 
    array (
      'database' => 
      array (
        'connection' => 'mysql',
      ),
    ),
  ),
  'trustedproxy' => 
  array (
    'proxies' => NULL,
    'headers' => 94,
  ),
  'vimeo' => 
  array (
    'default' => 'main',
    'connections' => 
    array (
      'main' => 
      array (
        'client_id' => '',
        'client_secret' => '',
        'access_token' => '',
      ),
      'alternative' => 
      array (
        'client_id' => 'your-alt-client-id',
        'client_secret' => 'your-alt-client-secret',
        'access_token' => NULL,
      ),
    ),
  ),
  'tinker' => 
  array (
    'commands' => 
    array (
    ),
    'alias' => 
    array (
    ),
    'dont_alias' => 
    array (
      0 => 'App\\Nova',
    ),
  ),
);
